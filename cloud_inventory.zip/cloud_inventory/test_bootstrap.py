from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch, Mock
import setup_flow as boot


class BootstrapTests(unittest.TestCase):
    def setUp(self):
        load = patch.object(boot, 'load_setup', return_value={})
        save = patch.object(boot, 'save_setup')
        self.addCleanup(load.stop)
        self.addCleanup(save.stop)
        self.load_setup = load.start()
        self.save_setup = save.start()

    def test_existing_cli_not_reinstalled(self):
        with patch.object(boot, 'refresh_windows_path'), patch.object(boot.shutil, 'which', return_value='aws'), patch.object(boot, 'verify_cli') as check, patch.object(boot, 'run_logged') as install:
            self.assertEqual(boot.ensure_cli('aws'),'aws')
            check.assert_called_once_with('aws','aws')
            install.assert_not_called()

    def test_windows_missing_cli_installs_then_verifies(self):
        with patch.object(boot, 'refresh_windows_path'), patch.object(boot.platform, 'system', return_value='Windows'), patch.object(boot.shutil, 'which', side_effect=[None,'winget','az.cmd']), patch.object(boot, 'ask', return_value=True), patch.object(boot, 'verify_cli') as check, patch.object(boot, 'run_logged') as install:
            self.assertEqual(boot.ensure_cli('azure'),'az.cmd')
            command=install.call_args.args[0]
            self.assertIn('Microsoft.AzureCLI',command)
            self.assertIn('--exact',command)
            self.assertIn('--accept-package-agreements',command)
            check.assert_called_once_with('azure','az.cmd')

    def test_declining_cli_install_skips(self):
        with patch.object(boot, 'refresh_windows_path'), patch.object(boot.shutil, 'which', return_value=None), patch.object(boot, 'ask', return_value=False), patch.object(boot, 'run_logged') as install:
            self.assertIsNone(boot.ensure_cli('azure'))
            install.assert_not_called()

    def test_requirements_install_then_pip_check(self):
        with patch.object(boot, 'run_logged') as run, patch.object(boot.importlib,'import_module'):
            boot.install_requirements()
            commands=[call.args[0] for call in run.call_args_list]
            self.assertIn('install',commands[0])
            self.assertIn(str(boot.HERE/'requirements.txt'),commands[0])
            self.assertEqual(commands[1][-1],'check')

    def test_aws_v1_rejected(self):
        with patch.object(boot.subprocess,'run',return_value=Mock(returncode=0,stdout='aws-cli/1.40.0',stderr='')):
            with self.assertRaises(RuntimeError):
                boot.verify_cli('aws','aws')

    def test_both_logins_before_capture(self):
        events=[]
        def cli(provider):
            events.append('cli_'+provider)
            return provider
        def azure(): events.append('login_azure')
        def aws(region):
            events.append('login_aws')
            return 'demo'
        def question(*args,**kwargs):
            events.append('capture')
            return False
        with patch.object(boot,'install_requirements',lambda:events.append('requirements')), patch.object(boot,'choose_providers',return_value=['azure','aws']), patch.object(boot,'ensure_cli',side_effect=cli), patch.object(boot,'login_azure',side_effect=azure), patch.object(boot,'login_aws',side_effect=aws), patch.object(boot,'inventory_workspace',side_effect=question):
            self.assertEqual(boot.wizard(),0)
        self.assertEqual(events,['requirements','cli_azure','cli_aws','login_azure','login_aws','capture'])

    def test_failed_login_never_exports(self):
        with patch.object(boot,'install_requirements'), patch.object(boot,'choose_providers',return_value=['azure']), patch.object(boot,'ensure_cli',return_value='az'), patch.object(boot,'login_azure',side_effect=RuntimeError('Expired')), patch.object(boot,'ask',return_value=False):
            with self.assertRaises(RuntimeError):
                boot.wizard()

    def test_cli_install_failure_not_reported_as_success(self):
        with patch.object(boot,'refresh_windows_path'), patch.object(boot.platform,'system',return_value='Windows'), patch.object(boot.shutil,'which',side_effect=[None,'winget']), patch.object(boot,'ask',return_value=True), patch.object(boot,'run_logged',side_effect=RuntimeError('installer denied')):
            with self.assertRaisesRegex(RuntimeError,'installer denied'):
                boot.ensure_cli('aws')


    def test_saved_setup_skips_requirements_and_initial_wizard(self):
        import hashlib

        setup = {'providers': ['aws'], 'profile': 'work-readonly',
                 'requirements_hash': hashlib.sha256((boot.HERE / 'requirements.txt').read_bytes()).hexdigest()}
        self.load_setup.return_value = setup
        with patch.object(boot, 'install_requirements') as install, patch.object(boot, 'inventory_workspace', return_value=0) as resume:
            self.assertEqual(boot.wizard(), 0)
        install.assert_not_called()
        resume.assert_called_once_with(setup, 'us-east-1', None, False)

    def test_saved_inventory_is_opened_without_capture(self):
        import json
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as directory:
            project = Path(directory)
            (project / 'output').mkdir()
            index = {'snapshots': [], 'failures': [], 'captured_at': 'saved'}
            (project / 'output' / 'snapshot-index.json').write_text(json.dumps(index))
            with patch.object(boot, 'HERE', project), patch('snapshots.collect') as collect, patch('snapshots.open_snapshot', return_value=0) as open_snapshot:
                self.assertEqual(boot.inventory_workspace({'providers': ['azure']}, 'us-east-1', None), 0)
            collect.assert_not_called()
            open_snapshot.assert_called_once_with(project, index, None)

if __name__=='__main__':
    unittest.main()
