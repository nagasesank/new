"""AWS read-only collectors and isolated per-region Terraform generation roots."""
import argparse
from collections import Counter
from datetime import date, datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import sys
import uuid

# service, operation, result key, inventory type, identity key, Terraform type
SPECS = [
 ('ec2', 'describe_vpcs', 'Vpcs', 'ec2:vpc', 'VpcId', 'aws_vpc'),
 ('ec2', 'describe_subnets', 'Subnets', 'ec2:subnet', 'SubnetId', 'aws_subnet'),
 ('ec2', 'describe_security_groups', 'SecurityGroups', 'ec2:security-group', 'GroupId', 'aws_security_group'),
 ('ec2', 'describe_route_tables', 'RouteTables', 'ec2:route-table', 'RouteTableId', 'aws_route_table'),
 ('ec2', 'describe_internet_gateways', 'InternetGateways', 'ec2:internet-gateway', 'InternetGatewayId', 'aws_internet_gateway'),
 ('ec2', 'describe_nat_gateways', 'NatGateways', 'ec2:nat-gateway', 'NatGatewayId', 'aws_nat_gateway'),
 ('ec2', 'describe_addresses', 'Addresses', 'ec2:elastic-ip', 'AllocationId', 'aws_eip'),
 ('ec2', 'describe_volumes', 'Volumes', 'ec2:volume', 'VolumeId', 'aws_ebs_volume'),
 ('ec2', 'describe_instances', 'Reservations', 'ec2:instance', 'InstanceId', 'aws_instance'),
 ('rds', 'describe_db_instances', 'DBInstances', 'rds:db-instance', 'DBInstanceIdentifier', 'aws_db_instance'),
 ('rds', 'describe_db_clusters', 'DBClusters', 'rds:db-cluster', 'DBClusterIdentifier', 'aws_rds_cluster'),
 ('lambda', 'list_functions', 'Functions', 'lambda:function', 'FunctionName', 'aws_lambda_function'),
 ('dynamodb', 'list_tables', 'TableNames', 'dynamodb:table', 'TableName', 'aws_dynamodb_table'),
 ('elbv2', 'describe_load_balancers', 'LoadBalancers', 'elbv2:load-balancer', 'LoadBalancerArn', 'aws_lb'),
 ('elbv2', 'describe_target_groups', 'TargetGroups', 'elbv2:target-group', 'TargetGroupArn', 'aws_lb_target_group'),
 ('eks', 'list_clusters', 'clusters', 'eks:cluster', 'name', 'aws_eks_cluster'),
 ('ecs', 'list_clusters', 'clusterArns', 'ecs:cluster', 'clusterArn', 'aws_ecs_cluster'),
 ('ecr', 'describe_repositories', 'repositories', 'ecr:repository', 'repositoryName', 'aws_ecr_repository'),
 ('logs', 'describe_log_groups', 'logGroups', 'logs:log-group', 'logGroupName', 'aws_cloudwatch_log_group'),
 ('cloudformation', 'describe_stacks', 'Stacks', 'cloudformation:stack', 'StackId', None),
]
SERVICES = sorted({s[0] for s in SPECS} | {'s3', 'iam'})
# Config detail operations are intentionally read-only. Lambda code and environment
# variables, credentials, secret payloads and S3 objects are not requested.
DETAILS = {
 'dynamodb:table': ('dynamodb', 'describe_table', 'TableName', 'Table'),
 'eks:cluster': ('eks', 'describe_cluster', 'name', 'cluster'),
}


def serial(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    raise TypeError(f'Unsupported JSON value {type(value).__name__}')


def dump(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=serial), encoding='utf-8')
    try:
        path.chmod(0o600)
    except OSError:
        pass


def clean(data):
    """Strip known sensitive properties, retaining structure for visibility."""
    sensitive = {'environment', 'environmentvariables', 'masteruserpassword', 'secretaccesskey',
                 'sessiontoken', 'password', 'accesskeyid', 'parameters', 'outputs', 'userdata'}
    if isinstance(data, dict):
        return {k: '[REDACTED]' if k.lower() in sensitive else clean(v)
                for k, v in data.items() if k != 'ResponseMetadata'}
    if isinstance(data, list):
        return [clean(v) for v in data]
    return data


def pages(client, operation, key, **kwargs):
    """Paginator availability is checked per operation, never silently truncate."""
    if client.can_paginate(operation):
        for page in client.get_paginator(operation).paginate(**kwargs):
            yield from page.get(key, [])
    else:
        result = getattr(client, operation)(**kwargs)
        if any(result.get(k) for k in ('NextToken', 'nextToken', 'NextMarker', 'Marker', 'ContinuationToken', 'NextContinuationToken', 'LastEvaluatedTableName', 'LastEvaluatedKey')) or result.get('IsTruncated'):
            raise RuntimeError(f'{operation}: pagination unsupported; refusing incomplete success')
        yield from result.get(key, [])


class Collector:
    def __init__(self, session, account, config, root):
        self.session, self.account, self.config, self.root = session, account, config, root
        self.resources, self.errors, self.coverage = [], [], []
        self.clients = {}

    def client(self, service, region):
        key = (service, region)
        if key not in self.clients:
            self.clients[key] = self.session.client(service, region_name=region, config=self.config)
        return self.clients[key]

    def record(self, service, region, operation, action):
        entry = {'service': service, 'region': region, 'operation': operation}
        try:
            result = action()
            entry.update(status='success', count=len(result) if isinstance(result, list) else None)
            return result
        except Exception as exc:
            # Do not print API response bodies or local credential contents.
            response = getattr(exc, 'response', {})
            code = response.get('Error', {}).get('Code', type(exc).__name__)
            absent_codes = {'NoSuchBucketPolicy', 'NoSuchTagSet', 'NoSuchPublicAccessBlockConfiguration',
                            'ServerSideEncryptionConfigurationNotFoundError'}
            if service == 's3' and code in absent_codes:
                entry.update(status='not_configured', error_code=code)
                return {'configuration_status': 'not_configured', 'code': code}
            entry.update(status='failed', error_code=code)
            self.errors.append(dict(entry))
            return None
        finally:
            self.coverage.append(entry)

    def add(self, kind, identity, name, region, properties):
        row = {'provider': 'aws', 'account_id': self.account, 'region': region,
               'type': kind, 'id': str(identity), 'name': str(name), 'properties': clean(properties)}
        self.resources.append(row)
        return row

    def regional(self, regions, services):
        for region in regions:
            for service, operation, key, kind, id_key, _ in SPECS:
                if service not in services:
                    continue
                print(f'  {region}: {service}.{operation}')
                items = self.record(service, region, operation,
                    lambda s=service, o=operation, k=key: list(pages(self.client(s, region), o, k)))
                if items is None:
                    continue
                if kind == 'ec2:instance':
                    items = [instance for reservation in items for instance in reservation.get('Instances', [])]
                for item in items:
                    props = {id_key: item} if isinstance(item, str) else item
                    identity = props.get(id_key)
                    if not identity:
                        self.errors.append({'service': service, 'region': region, 'operation': operation,
                                            'error_code': 'MissingImportIdentity'})
                        continue
                    tags = props.get('Tags', [])
                    tags = tags if isinstance(tags, list) else []
                    name = next((t['Value'] for t in tags if t.get('Key') == 'Name'), identity)
                    row = self.add(kind, identity, name, region, props)
                    if kind in DETAILS:
                        svc, op, parameter, result_key = DETAILS[kind]
                        detail = self.record(svc, region, op,
                            lambda: getattr(self.client(svc, region), op)(**{parameter: identity})[result_key])
                        if detail is not None:
                            row['properties'] = clean(detail)
                    if kind == 'ecs:cluster':
                        detail = self.record(service, region, 'describe_clusters',
                            lambda: self.client(service, region).describe_clusters(clusters=[identity]))
                        if detail:
                            row['properties']['detail'] = clean(detail)
                    if kind == 'cloudformation:stack':
                        members = self.record(service, region, 'list_stack_resources',
                            lambda: list(pages(self.client(service, region), 'list_stack_resources',
                                               'StackResourceSummaries', StackName=identity)))
                        if members is not None:
                            row['properties']['members'] = clean(members)

    def buckets(self, home_region, selected_regions):
        s3 = self.client('s3', home_region)
        buckets = self.record('s3', 'global', 'list_buckets', lambda: list(pages(s3, 'list_buckets', 'Buckets')))
        for bucket in buckets or []:
            name = bucket['Name']
            result = self.record('s3', 'global', 'get_bucket_location', lambda: s3.get_bucket_location(Bucket=name))
            if result is None:
                # Unknown region is inventory-only, never an incorrect provider mapping.
                self.add('s3:bucket-region-unknown', name, name, 'global', bucket)
                continue
            region = result.get('LocationConstraint') or 'us-east-1'
            region = 'eu-west-1' if region == 'EU' else region
            if region not in selected_regions:
                continue
            row = self.add('s3:bucket', name, name, region, bucket)
            regional_s3 = self.client('s3', region)
            for op in ('get_bucket_versioning', 'get_bucket_encryption', 'get_public_access_block',
                       'get_bucket_policy', 'get_bucket_tagging'):
                data = self.record('s3', region, op,
                                   lambda op=op: getattr(regional_s3, op)(Bucket=name))
                if data is not None:
                    row['properties'][op] = clean(data)

    def iam(self, home_region):
        client = self.client('iam', home_region)
        roles = self.record('iam', 'global', 'list_roles', lambda: list(pages(client, 'list_roles', 'Roles')))
        for role in roles or []:
            row = self.add('iam:role', role['RoleName'], role['RoleName'], 'global', role)
            for op, key in [('list_attached_role_policies', 'AttachedPolicies'), ('list_role_policies', 'PolicyNames')]:
                data = self.record('iam', 'global', op,
                                  lambda op=op, key=key: list(pages(client, op, key, RoleName=role['RoleName'])))
                if data is not None:
                    row['properties'][op] = data
        policies = self.record('iam', 'global', 'list_policies',
            lambda: list(pages(client, 'list_policies', 'Policies', Scope='Local')))
        for policy in policies or []:
            row = self.add('iam:policy', policy['Arn'], policy['PolicyName'], 'global', policy)
            detail = self.record('iam', 'global', 'get_policy_version',
                lambda: client.get_policy_version(PolicyArn=policy['Arn'], VersionId=policy['DefaultVersionId']))
            if detail is not None:
                row['properties']['default_version'] = clean(detail.get('PolicyVersion', {}))


def validate_inventory(rows, account):
    if not isinstance(rows, list):
        raise ValueError('AWS inventory must be an array.')
    for r in rows:
        if not isinstance(r, dict) or any(not isinstance(r.get(k), str) or not r[k] for k in ('id', 'name', 'type', 'region', 'account_id')):
            raise ValueError('AWS rows require nonempty id/name/type/region/account_id strings.')
        if r.get('provider') != 'aws' or r['account_id'] != account:
            raise ValueError('AWS inventory provider/account mismatch.')
        if not re.fullmatch(r'[a-z0-9-]+', r['region']):
            raise ValueError('Invalid region path.')


def main():
    from workflow import aws_login, save_exports, select_types
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile')
    p.add_argument('--account-id', help='Expected 12-digit account; inferred from JSON if omitted')
    p.add_argument('--regions', nargs='+', help='Specific regions; omitted means all enabled regions')
    p.add_argument('--choose-region', action='store_true', help='Select one enabled region and capture regional resources only')
    p.add_argument('--home-region', default='us-east-1', help='Region for STS/region discovery/global clients')
    p.add_argument('--services', nargs='+', choices=SERVICES, default=SERVICES)
    p.add_argument('--environment', choices=['dev', 'uat', 'prod'], default='dev', help='Terraform environment (default: dev)')
    p.add_argument('--output', default='output')
    p.add_argument('--on-prem', help='Optional on-prem workload inventory JSON')
    p.add_argument('--overrides', '--csv', dest='csv', metavar='FILE', help='Client CSV or JSON requests')
    p.add_argument('--csv-only', action='store_true', help='Generate new resources without a baseline inventory')
    p.add_argument('--inventory', help='Offline AWS normalized inventory JSON')
    p.add_argument('--scope', choices=['all', 'types', 'resources'])
    p.add_argument('--select', nargs='*', default=[], help='Exact resource IDs; match across selected regions')
    p.add_argument('--export-only', action='store_true', help='Save full and selected JSON; skip Terraform')
    p.add_argument('--generate', action='store_true')
    p.add_argument('--non-interactive', action='store_true')
    p.add_argument('--skip-login', action='store_true', help='Reuse credentials verified by setup wizard')
    p.add_argument('--details', action='store_true', help='Accepted for common CLI compatibility; AWS detail reads are always enabled')
    args = p.parse_args()
    if args.csv_only and (not args.csv or args.inventory or not args.account_id):
        p.error('--csv-only requires --csv and --account-id, and cannot be combined with --inventory')
    offline = args.inventory is not None or args.csv_only
    if args.choose_region and (offline or args.regions):
        p.error('--choose-region requires live discovery and cannot be combined with --regions')
    if args.export_only and args.generate:
        p.error('--export-only cannot be combined with --generate')
    if args.account_id and not re.fullmatch(r'\d{12}', args.account_id):
        p.error('--account-id must contain 12 digits')
    collector = None
    if offline:
        from workflow import load_inventory
        rows = load_inventory(args.inventory) if args.inventory else []
        accounts = {r.get('account_id') for r in rows if isinstance(r, dict)}
        if not args.account_id:
            if len(accounts) != 1 or not next(iter(accounts)):
                p.error('Cannot infer a single AWS account; supply --account-id')
            args.account_id = next(iter(accounts))
        if not re.fullmatch(r'\d{12}', args.account_id):
            p.error('Inventory account ID must contain 12 digits')
        account = args.account_id
        validate_inventory(rows, account)
        regions = args.regions or sorted({r['region'] for r in rows if r['region'] != 'global'})
        rows = [r for r in rows if r['region'] in regions or r['region'] == 'global']
        identity = {'Account': account, 'source': 'offline'}
    else:
        if not args.non_interactive:
            if not args.skip_login:
                args.profile = aws_login(args.profile, args.home_region)
            if not args.account_id:
                args.account_id = input('Expected account ID (blank to use verified account): ').strip() or None
                if args.account_id and not re.fullmatch(r'\d{12}', args.account_id):
                    raise ValueError('Expected account ID must contain 12 digits.')
        try:
            import boto3
            from botocore.config import Config
        except ImportError:
            raise RuntimeError('Install AWS dependencies: python -m pip install -r requirements.txt')
        config = Config(retries={'mode': 'standard', 'max_attempts': 6}, connect_timeout=10, read_timeout=60)
        session = boto3.Session(profile_name=args.profile, region_name=args.home_region)
        if session.get_partition_for_region(args.home_region) != 'aws':
            raise ValueError('v2 supports commercial AWS only.')
        identity = session.client('sts', config=config).get_caller_identity()
        account = identity['Account']
        if args.account_id and account != args.account_id:
            raise ValueError('Active AWS identity does not match --account-id. No discovery performed.')
        print(f'AWS account: {account}; identity: {identity["Arn"]}')
        if args.regions:
            available = set(session.get_available_regions('ec2'))
            if any(r not in available for r in args.regions):
                raise ValueError('Invalid/unknown commercial region; update boto3 if region is new.')
            regions = sorted(set(args.regions))
        else:
            response = session.client('ec2', config=config).describe_regions(AllRegions=False)
            regions = sorted(r['RegionName'] for r in response['Regions'])
        regional_only = args.choose_region or (not args.non_interactive and not args.regions)
        if regional_only:
            from cloud_inventory import choose
            print(f'Select AWS region for account {account}:')
            regions = [choose(regions, str)]
        rows = []
    if any(not re.fullmatch(r'[a-z0-9-]+', r) for r in regions):
        raise ValueError('Invalid region.')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    root = Path(args.output) / 'aws' / account / stamp
    root.mkdir(parents=True, mode=0o700)
    print(f'Export folder: {root.resolve()}')
    report = {'provider': 'aws', 'account_id': account, 'regions': regions, 'requested_services': args.services,
              'source': 'offline' if offline else 'AWS SDK read-only APIs', 'status': 'running',
              'limitations': ['Only documented collectors; not all AWS services or child resources',
                'No secret values, object contents or application artifacts intentionally exported',
                'No state adoption; generated Terraform needs review and ownership handoff',
                'Separate region/global Terraform roots; no cross-root dependency refactoring']}
    if not offline and regional_only:
        report['limitations'].append('Region-scoped capture excludes global IAM and buckets whose region could not be verified')
    errors, coverage = [], []
    try:
        dump(root / 'identity.json', clean(identity))
        if not offline:
            collector = Collector(session, account, config, root)
            collector.regional(regions, args.services)
            if 's3' in args.services:
                collector.buckets(args.home_region, regions)
            if 'iam' in args.services and not regional_only:
                collector.iam(args.home_region)
            rows = ([row for row in collector.resources if row['region'] in regions]
                    if regional_only else collector.resources)
            errors, coverage = collector.errors, collector.coverage
        save_exports(root, rows, dump)
        dump(root / 'discovery/resource_counts.json', dict(Counter(r['type'] for r in rows)))
        scope = args.scope or 'all'
        if not args.non_interactive and not args.scope:
            scope = input('Select scope [types/all/resources] (types): ').strip().lower() or 'types'
        if scope not in ('all', 'types', 'resources'):
            raise ValueError('Scope must be all, types or resources.')
        selected = args.select
        if scope == 'resources' and not selected and not args.non_interactive:
            for r in rows:
                print(f'{r["region"]} {r["type"]} {r["id"]}')
            selected = [s.strip() for s in input('Comma-separated exact resource IDs: ').split(',') if s.strip()]
        chosen = select_types(rows, selected, not args.non_interactive) if scope == 'types' else (rows if scope == 'all' else [r for r in rows if r['id'] in selected])
        if scope == 'resources' and not chosen:
            raise ValueError('No resources matched selection.')
        action = 'export' if args.export_only else 'generate'
        if not args.non_interactive and not args.generate and not args.export_only:
            action = input('Next action [export/generate] (generate): ').strip().lower() or 'generate'
            if action not in ('export', 'generate'):
                raise ValueError('Choose export or generate.')
        from workflow import choose_client_override
        override = choose_client_override(args.csv, interactive=not args.non_interactive and action == 'generate')
        if override:
            from client_csv import apply_requests
            chosen = apply_requests(override, 'aws', account, chosen)
            report['client_requests'] = sum('_csv_action' in resource for resource in chosen)
        dump(root / 'selection/resources.json', chosen)
        from migration import write_migration
        report['migration_gaps'] = write_migration(root, 'aws', rows, chosen, args.on_prem, dump)
        report.update(discovered=len(rows), selected=len(chosen), selection_scope=scope)
        print(f'Selected JSON saved: {(root / "selection/resources.json").resolve()}')
        if action == 'export':
            report.update(terraform_status='not_requested', status='partial' if errors else 'completed_with_documented_coverage_limits')
            return 2 if errors else 0
        if not override:
            print('Generating Terraform from the available inventory JSON.')
        from terraform_json import generate_json
        reports = generate_json('aws', chosen, root / 'terraform-infra', account,
                                home_region=args.home_region, profile=args.profile, environment=args.environment)
        gaps = [gap for item in reports for gap in item['unsupported']]
        report.update(terraform_status='generated_from_json_review_required', unsupported=len(gaps),
                      emitted_blocks=sum(item['emitted_blocks'] for item in reports),
                      required_inputs=sum(len(item['missing_inputs']) for item in reports))
        report['status'] = 'partial' if errors or gaps else 'completed_with_documented_coverage_limits'
    except BaseException:
        report['status'] = 'failed'
        raise
    finally:
        if collector:
            # Save partial discovery even on cancellation or failure.
            dump(root / 'discovery/resources.json',
                 [row for row in collector.resources if row['region'] in regions]
                 if regional_only else collector.resources)
            errors = collector.errors + [e for e in errors if e not in collector.errors]
            coverage = collector.coverage
        dump(root / 'collector_coverage.json', coverage)
        dump(root / 'errors.json', errors)
        dump(root / 'coverage.json', report)
        from workflow import show_run_summary
        show_run_summary(root, report)
    return 2 if report['status'] == 'partial' else 0
