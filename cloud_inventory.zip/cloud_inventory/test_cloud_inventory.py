import unittest
from pathlib import Path
import tempfile
from unittest.mock import patch, Mock
import cloud_inventory as tool

class Tests(unittest.TestCase):
    def test_pagination_and_deduplication(self):
        calls = []
        def page(body):
            calls.append(body)
            if len(calls) == 1:
                return {'data': [{'id': '/a'}], '$skipToken': 'next'}
            return {'data': [{'id': '/A'}, {'id': '/b'}]}
        self.assertEqual(len(tool.graph('sub', 'query', page)), 2)
        self.assertEqual(calls[1]['options']['$skipToken'], 'next')
        self.assertEqual(calls[0]['query'], calls[1]['query'])
    def test_truncation_is_failure(self):
        with self.assertRaises(RuntimeError):
            tool.graph('sub', 'query', lambda _: {'data': [], 'resultTruncated': 'true'})
if __name__ == '__main__':
    unittest.main()
