"""Shared CLI sign-in, export index and resource selection helpers."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import uuid


def pick_many(items, label, prompt, input_fn=None):
    input_fn = input_fn or input
    if not items:
        return []
    for index, item in enumerate(items, 1):
        print(f'  {index}. {label(item)}')
    while True:
        answer = input_fn(prompt + ' [all or comma-separated numbers]: ').strip().lower()
        if answer == 'all':
            return list(items)
        pieces = [part.strip() for part in answer.split(',') if part.strip()]
        if pieces and all(p.isdigit() and 1 <= int(p) <= len(items) for p in pieces):
            return [items[i] for i in sorted({int(p) - 1 for p in pieces})]
        print('Choose all, or valid numbers such as 1,3.')


def select_types(rows, selectors=None, interactive=False):
    counts = Counter(r['type'] for r in rows)
    kinds = sorted(counts, key=str.lower)
    if not selectors:
        if not interactive:
            raise ValueError('--scope types requires --select TYPE ...')
        selectors = pick_many(kinds, lambda t: f'{t} ({counts[t]} resources)', 'Select resource types')
    wanted = {s.lower() for s in selectors}
    selected = [r for r in rows if r['type'].lower() in wanted]
    missing = wanted - {k.lower() for k in kinds}
    if missing:
        raise ValueError('Resource types not present in export: ' + ', '.join(sorted(missing)))
    if interactive and selected:
        selected = pick_many(selected, lambda r: f'{r["name"]} | {r.get("region", r.get("location", ""))} | {r["id"]}',
                             'Select resources within those types')
    return selected


def save_exports(root, rows, dump):
    """Save full snapshot first, then indexed per-type snapshots and latest pointer."""
    root = Path(root)
    dump(root / 'discovery/resources.json', rows)
    by_type = {}
    for row in rows:
        by_type.setdefault(row['type'], []).append(row)
    index = []
    for kind, group in sorted(by_type.items()):
        safe = re.sub(r'[^a-z0-9_-]', '_', kind.lower())[:90]
        digest = hashlib.sha256(kind.encode()).hexdigest()[:10]
        relative = f'discovery/by_type/{safe}_{digest}.json'
        dump(root / relative, group)
        index.append({'type': kind, 'count': len(group), 'file': relative})
    dump(root / 'discovery/type_index.json', index)
    pointer = {'run_directory': str(root.resolve()),
               'inventory_file': str((root / 'discovery/resources.json').resolve()),
               'type_index_file': str((root / 'discovery/type_index.json').resolve())}
    # Atomic pointer update; concurrent runs cannot produce a half-written pointer.
    temporary = root.parent / ('.latest_' + uuid.uuid4().hex + '.json')
    dump(temporary, pointer)
    os.replace(temporary, root.parent / 'latest_export.json')
    print(f'Full JSON export saved: {(root / "discovery/resources.json").resolve()}')
    print(f'Resource-type index: {(root / "discovery/type_index.json").resolve()}')


def require_cli(name):
    path = shutil.which(name)
    if not path:
        commands = {'az': 'winget install --exact --id Microsoft.AzureCLI',
                    'aws': 'winget install --exact --id Amazon.AWSCLI'}
        raise RuntimeError(f'{name} CLI not found. On Windows run: {commands[name]}. Then reopen PowerShell.')
    return path


def cli_interactive(args):
    result = subprocess.run(args, check=False)
    if result.returncode:
        raise RuntimeError(f'{Path(args[0]).name} sign-in/configuration failed. Retry after checking CLI setup.')


def azure_login(tenant=None, default_mode='existing'):
    cli = require_cli('az')
    print('Azure CLI found. Authentication: existing / browser / device')
    mode = input(f'Azure sign-in mode [{default_mode}]: ').strip().lower() or default_mode
    if mode not in ('existing', 'browser', 'device'):
        raise ValueError('Choose existing, browser or device.')
    if mode != 'existing':
        tenant = tenant or input('Tenant ID/domain (blank for available tenants): ').strip()
        args = [cli, 'login', '--output', 'none']
        if tenant:
            args += ['--tenant', tenant]
        if mode == 'device':
            args.append('--use-device-code')
        cli_interactive(args)


def aws_login(profile, home_region):
    cli = require_cli('aws')
    if profile is None:
        result = subprocess.run([cli, 'configure', 'list-profiles'], capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and result.stdout.strip():
            print('Available AWS profiles:\n' + result.stdout.strip())
        profile = input('AWS profile (blank for standard credential chain): ').strip() or None
    print('AWS authentication: existing / sso / setup-sso / configure')
    mode = input('AWS sign-in mode [existing]: ').strip().lower() or 'existing'
    if mode not in ('existing', 'sso', 'setup-sso', 'configure'):
        raise ValueError('Choose existing, sso, setup-sso or configure.')
    if mode != 'existing':
        if not profile:
            profile = input('Profile name to create/use (e.g. migration-readonly): ').strip()
            if not profile:
                raise ValueError('A named AWS profile is required for setup/login.')
        if mode == 'setup-sso':
            cli_interactive([cli, 'configure', 'sso', '--profile', profile])
        if mode == 'configure':
            cli_interactive([cli, 'configure', '--profile', profile])
        else:
            cli_interactive([cli, 'sso', 'login', '--profile', profile])
    identity = aws_identity(profile, home_region)
    print(f'AWS CLI identity verified: account {identity["Account"]}; {identity["Arn"]}')
    return profile


def aws_identity(profile, home_region):
    cli = require_cli('aws')
    command = [cli, 'sts', 'get-caller-identity', '--region', home_region, '--output', 'json', '--no-cli-pager']
    if profile:
        command += ['--profile', profile]
    response = subprocess.run(command, capture_output=True, text=True, timeout=90)
    if response.returncode:
        raise RuntimeError('AWS CLI identity check failed. Refresh credentials/SSO and retry. No discovery performed.')
    return json.loads(response.stdout)


def load_inventory(filename):
    data = json.loads(Path(filename).read_text(encoding='utf-8-sig'))
    if isinstance(data, dict):
        data = data.get('resources', data.get('data'))
    if not isinstance(data, list):
        raise ValueError('Inventory must be an array, or an object containing resources/data array')
    return data


def show_run_summary(root, report):
    print(f'\nOutput summary | {report["status"]}')
    print(f'  Run folder: {root.resolve()}')
    artifacts = {
        'Coverage': 'coverage.json',
        'Inventory': 'discovery/resources.json',
        'Selected values': 'selection/resources.json',
        'Migration plan': 'migration/migration_plan.json',
        'Topology': 'migration/cloud_topology.mmd',
        'Terraform repository': 'terraform-infra',
    }
    for label, path in artifacts.items():
        if (root / path).exists():
            print(f'  {label}: {path}')
    for path in sorted((root / 'terraform-infra').rglob('terraform.tfvars')):
        print(f'  Terraform values: {path.relative_to(root)}')


def choose_client_override(supplied, *, interactive):
    if supplied:
        print(f'Reading client overrides: {supplied}')
        return supplied
    if not interactive:
        return None
    while True:
        answer = input('Do you have a client CSV or JSON file? [y/N]: ').strip().lower()
        if answer in ('', 'n', 'no'):
            return None
        if answer in ('y', 'yes'):
            break
        print('Enter y or n.')
    while True:
        filename = input('Client CSV/JSON file path (Enter to use inventory only): ').strip().strip('"')
        if not filename:
            return None
        path = Path(filename).expanduser()
        if path.suffix.lower() in ('.csv', '.json') and path.is_file():
            print(f'Reading client overrides: {path}')
            return path
        print('Enter the path to an existing .csv or .json file.')
