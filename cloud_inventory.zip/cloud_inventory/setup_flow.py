#!/usr/bin/env python3
"""One-command setup: isolated dependencies → CLI install → login → export prompt."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
from tempfile import NamedTemporaryFile
import venv

HERE = Path(__file__).resolve().parent
PACKAGES = {'azure': ('az', 'Microsoft.AzureCLI'), 'aws': ('aws', 'Amazon.AWSCLI')}


def workspace_dir():
    return HERE.parent if HERE.name == 'scripts' else HERE


class Console:
    def __init__(self):
        self.color = (sys.stdout.isatty() and not os.getenv('NO_COLOR') and
            (os.name != 'nt' or os.getenv('WT_SESSION') or os.getenv('TERM') or os.getenv('ANSICON')))

    def text(self, message, color=None):
        colors = {'blue': '\033[96m', 'green': '\033[92m', 'yellow': '\033[93m', 'red': '\033[91m'}
        print((colors.get(color, '') + message + '\033[0m') if self.color and color else message, flush=True)

    def step(self, number, title):
        self.text(f'\n[{number}/5] {title}', 'blue')

    def ok(self, message):
        self.text('  [OK] ' + message, 'green')

    def info(self, message):
        self.text('  [INFO] ' + message, 'yellow')


console = Console()


def ask(prompt, default='y'):
    suffix = '[Y/n]' if default == 'y' else '[y/N]'
    return (input(prompt + ' ' + suffix + ': ').strip().lower() or default) in ('y', 'yes')


def run_logged(args, title):
    """Only installer/dependency output is logged; login flows never use this."""
    folder = workspace_dir() / 'setup_logs'
    folder.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    log = folder / (stamp + '.log')
    start = time.monotonic()
    console.info(title + '...')
    with log.open('w', encoding='utf-8') as stream:
        process = subprocess.Popen(args, stdout=stream, stderr=subprocess.STDOUT)
        while process.poll() is None:
            if sys.stdout.isatty():
                print(f'\r  [WORKING] {title} | {int(time.monotonic() - start)}s elapsed', end='', flush=True)
            time.sleep(0.25)
    if sys.stdout.isatty():
        print()
    if process.returncode:
        raise RuntimeError(f'{title} failed (exit {process.returncode}). Details: {log}')
    console.ok(title + ' complete')


def environment_python(directory):
    return Path(directory) / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def ensure_environment():
    if sys.version_info < (3, 10):
        raise RuntimeError('Python 3.10+ is required. Install Python, then run python cloud_inventory.py again.')
    target = workspace_dir() / '.venv'
    interpreter = environment_python(target)
    if not interpreter.exists():
        console.info('Creating isolated project environment...')
        venv.EnvBuilder(with_pip=True).create(target)
    return interpreter


def install_requirements():
    run_logged([sys.executable, '-m', 'pip', 'install', '--no-input', '--disable-pip-version-check',
                '-r', str(HERE / 'requirements.txt')], 'Installing requirements.txt')
    run_logged([sys.executable, '-m', 'pip', 'check'], 'Checking dependency compatibility')
    importlib.invalidate_caches()
    for module in ('boto3', 'hcl2'):
        importlib.import_module(module)
    console.ok('AWS SDK and HCL parser ready')


def refresh_windows_path():
    if platform.system() != 'Windows':
        return
    paths = [os.environ.get('PATH', '')]
    try:
        import winreg
        for hive, keyname in [(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\Session Manager\Environment'),
                              (winreg.HKEY_CURRENT_USER, r'Environment')]:
            try:
                with winreg.OpenKey(hive, keyname) as key:
                    entry, _ = winreg.QueryValueEx(key, 'Path')
                    paths.append(os.path.expandvars(entry))
            except OSError:
                pass
    except ImportError:
        pass
    # Vendor install locations cover a successful install before PATH refresh.
    for base in (os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)')):
        if base:
            paths += [str(Path(base) / 'Microsoft SDKs/Azure/CLI2/wbin'),
                      str(Path(base) / 'Amazon/AWSCLIV2')]
    local = os.environ.get('LOCALAPPDATA')
    if local:
        paths += [str(Path(local) / 'Programs/Amazon/AWSCLIV2'),
                  str(Path(local) / 'Microsoft/WinGet/Links')]
    os.environ['PATH'] = os.pathsep.join(dict.fromkeys(p for p in paths if p))


def verify_cli(provider, executable):
    command = [executable, 'version', '--output', 'json'] if provider == 'azure' else [executable, '--version']
    response = subprocess.run(command, capture_output=True, text=True, timeout=60)
    if response.returncode:
        raise RuntimeError(f'{provider} CLI exists but its version check failed. Repair the CLI installation.')
    if provider == 'aws' and not (response.stdout + response.stderr).strip().startswith('aws-cli/2.'):
        raise RuntimeError('AWS CLI v2 is required for this wizard; upgrade an existing v1 installation.')
    return executable


def ensure_cli(provider):
    executable, package = PACKAGES[provider]
    refresh_windows_path()
    found = shutil.which(executable)
    if found:
        verify_cli(provider, found)
        console.ok(f'{provider.upper()} CLI already installed')
        return found
    console.info(f'{provider.upper()} CLI is not installed')
    if not ask(f'Install {provider.upper()} CLI now?'):
        console.info(f'Skipping {provider.upper()} setup')
        return None
    system = platform.system()
    if system == 'Windows':
        winget = shutil.which('winget')
        if not winget:
            raise RuntimeError('WinGet is missing. Install/update Microsoft App Installer, then rerun python cloud_inventory.py. '
                               'No cloud login or export has run.')
        run_logged([winget, 'install', '--exact', '--id', package, '--source', 'winget',
                    '--accept-package-agreements', '--accept-source-agreements'], f'Installing {provider.upper()} CLI')
    elif system == 'Darwin' and shutil.which('brew'):
        brew_package = 'azure-cli' if provider == 'azure' else 'awscli'
        run_logged([shutil.which('brew'), 'install', brew_package], f'Installing {provider.upper()} CLI')
    else:
        raise RuntimeError('Automatic CLI installation supports Windows with WinGet and macOS with Homebrew. '
                           'Install the vendor CLI for your platform and rerun; no sudo/download scripts are executed.')
    refresh_windows_path()
    found = shutil.which(executable)
    if not found:
        raise RuntimeError(f'{provider.upper()} install finished but the CLI is unavailable. Reopen the terminal and rerun python cloud_inventory.py.')
    verify_cli(provider, found)
    console.ok(f'{provider.upper()} CLI installed and verified')
    return found


def choose_providers():
    while True:
        answer = input('Set up clouds [both/azure/aws] (both): ').strip().lower() or 'both'
        if answer == 'both':
            return ['azure', 'aws']
        if answer in PACKAGES:
            return [answer]
        console.info('Choose both, azure or aws.')


def login_azure():
    from workflow import azure_login
    cli = shutil.which('az')
    check = subprocess.run([cli, 'account', 'list', '--output', 'json', '--only-show-errors'],
                           capture_output=True, text=True, timeout=90)
    try:
        available = json.loads(check.stdout) if check.returncode == 0 else []
    except ValueError:
        available = []
    if not available:
        console.info('No cached Azure subscriptions. Choose browser or device sign-in next.')
    azure_login(default_mode='browser' if not available else 'existing')
    verify_azure_session()
    console.ok('Azure login verified; token values are not printed or saved')


def verify_azure_session():
    token = subprocess.run([shutil.which('az'), 'account', 'get-access-token',
                            '--resource', 'https://management.azure.com/', '--query', 'expiresOn',
                            '--output', 'tsv', '--only-show-errors'],
                           capture_output=True, text=True, timeout=90)
    if token.returncode:
        raise RuntimeError('Azure session could not be verified.')


def login_aws(home_region):
    from workflow import aws_login
    profile = aws_login(None, home_region)
    console.ok('AWS login and account verified')
    return profile


def load_setup():
    path = workspace_dir() / '.venv' / 'cloud-inventory-setup.json'
    try:
        setup = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    if not isinstance(setup, dict):
        return {}
    providers = setup.get('providers')
    if (not isinstance(providers, list) or not providers
            or any(provider not in ('azure', 'aws') for provider in providers)
            or (setup.get('profile') is not None and not isinstance(setup['profile'], str))):
        return {}
    return setup


def save_setup(setup):
    folder = workspace_dir() / '.venv'
    with NamedTemporaryFile(mode='w', dir=folder, encoding='utf-8', delete=False) as stream:
        temporary = Path(stream.name)
        json.dump(setup, stream)
    try:
        temporary.replace(folder / 'cloud-inventory-setup.json')
    finally:
        temporary.unlink(missing_ok=True)


def inventory_workspace(setup, home_region, on_prem, refresh=False, **options):
    from snapshots import collect, open_snapshot

    output = options.get('output') or workspace_dir() / 'output'
    index_file = output / 'snapshot-index.json'
    if refresh or not index_file.exists():
        refresh_windows_path()
        index, report = collect(HERE, setup, home_region, output)
        console.info(f'Capture report: {report}')
        if not index['snapshots'] and index['failures']:
            return 2
    else:
        index = json.loads(index_file.read_text(encoding='utf-8'))
    return open_snapshot(HERE, index, on_prem, **options)


def wizard(home_region='us-east-1', on_prem=None, configure=False, refresh=False, **options):
    console.text('\nCLOUD INVENTORY  |  SETUP -> LOGIN -> JSON -> TERRAFORM', 'blue')
    setup = {} if configure else load_setup()
    requirements_hash = hashlib.sha256((HERE / 'requirements.txt').read_bytes()).hexdigest()
    if setup.get('requirements_hash') != requirements_hash:
        console.step(1, 'Installing requirements...')
        install_requirements()
        if setup:
            setup['requirements_hash'] = requirements_hash
            save_setup(setup)
    if setup:
        console.ok('Using saved setup')
        return inventory_workspace(setup, home_region, on_prem, refresh, **options)
    console.step(2, 'Checking Azure / AWS CLI...')
    selected = choose_providers()
    ready = [provider for provider in selected if ensure_cli(provider)]
    if not ready:
        raise RuntimeError('No cloud CLI is ready. Rerun setup or use python cloud_inventory.py with your inventory JSON.')
    console.step(3, 'Logging in to selected clouds...')
    profile = None
    authenticated = []
    for provider in ready:
        console.text(f'\n  {provider.upper()} ACCOUNT SETUP', 'blue')
        try:
            if provider == 'azure':
                login_azure()
            else:
                profile = login_aws(home_region)
            authenticated.append(provider)
        except (RuntimeError, subprocess.SubprocessError) as exc:
            console.info(str(exc))
            if not ask(f'Retry {provider.upper()} login?', default='n'):
                if ask(f'Skip {provider.upper()} for this run?', default='n'):
                    continue
                raise RuntimeError(f'{provider.upper()} login is incomplete. Export was not started.')
            if provider == 'azure':
                login_azure()
            else:
                profile = login_aws(home_region)
            authenticated.append(provider)
    if not authenticated:
        raise RuntimeError('No verified cloud session. Export was not started.')
    setup = {'providers': authenticated, 'profile': profile, 'requirements_hash': requirements_hash}
    save_setup(setup)
    console.step(4, 'Capturing accessible accounts and subscriptions...')
    return inventory_workspace(setup, home_region, on_prem, refresh=True, **options)


def push_committed_branch(repository, remote):
    def git(*arguments):
        return subprocess.check_output(['git', '-C', str(repository), *arguments], text=True).strip()

    if remote not in git('remote').splitlines():
        raise ValueError(f'Git remote {remote!r} is not configured.')
    if git('status', '--porcelain'):
        raise ValueError('Review and commit the working tree before pushing.')
    branch = git('branch', '--show-current')
    if not branch:
        raise ValueError('Check out a named Git branch before pushing.')
    print(f'Pushing {branch} to {remote}...', flush=True)
    return subprocess.run(['git', '-C', str(repository), 'push', '--', remote,
                           f'HEAD:refs/heads/{branch}']).returncode


def main():
    parser = argparse.ArgumentParser(
        description='Capture Azure and AWS inventory and build migration artifacts from saved snapshots.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples
  python cloud_inventory.py --list
  python cloud_inventory.py --snapshot 1 --overrides client.csv --mode generate
  python cloud_inventory.py --snapshot 1 --overrides client.json --mode generate
  python cloud_inventory.py --git-push ./review-repo --remote origin
  python cloud_inventory.py --snapshot 1 --mode export
  python cloud_inventory.py --snapshot 1 --mode generate --save-to ./terraform-review
  python cloud_inventory.py --refresh --output ./cloud-capture
  python cloud_inventory.py --output ./cloud-capture --list

Saved files
  OUTPUT/snapshot-index.json              Snapshot list and capture errors
  OUTPUT/snapshot-batches/                Original inventory JSON and batch reports
  DESTINATION/<cloud>/<scope>/<run>/      Artifacts from the selected snapshot
    discovery/ and selection/            Inventory and selected resources (JSON)
    migration/                           Migration plan (JSON) and topology (Mermaid)
    terraform-infra/environments/        Terraform roots and tfvars by environment
    terraform-infra/modules/             Provider-specific service modules
  DESTINATION defaults to OUTPUT. --save-to changes only the artifact destination.
  --mode processes all resources in the selected snapshot.
""")
    parser.add_argument('--in-environment', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--setup', action='store_true', help='Run initial setup again and replace saved preferences')
    parser.add_argument('--refresh', action='store_true', help='Capture a fresh cloud inventory batch')
    parser.add_argument('--home-region', default='us-east-1')
    parser.add_argument('--on-prem', help='Optional on-prem workload inventory JSON')
    parser.add_argument('--environment', choices=['dev', 'uat', 'prod'], help='Terraform environment (default: dev)')
    parser.add_argument('--output', type=Path, metavar='DIR', help='Snapshot workspace directory (default: project output/)')
    parser.add_argument('--overrides', '--csv', dest='csv', type=Path, metavar='FILE', help='Apply client CSV or JSON requests to the selected snapshot')
    parser.add_argument('--git-push', type=Path, metavar='REPO', help='Push the current committed branch from a clean Git repo')
    parser.add_argument('--remote', default='origin', help='Git remote for --git-push (default: origin)')
    parser.add_argument('--save-to', type=Path, metavar='DIR', help='Save derived artifacts in this directory')
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument('--list', action='store_true', dest='list_only', help='List saved snapshots offline and exit')
    selection.add_argument('--snapshot', type=int, metavar='N', help='Open a saved snapshot by its displayed number')
    parser.add_argument('--mode', choices=['export', 'generate'],
                        help='Export JSON and migration files, or also generate Terraform (default: interactive)')
    args = parser.parse_args()
    if args.git_push:
        if args.setup or args.refresh or args.list_only or args.snapshot or args.csv or args.mode or args.save_to or args.output or args.on_prem:
            parser.error('--git-push is a separate action. Commit reviewed files first.')
        return push_committed_branch(args.git_push.resolve(), args.remote)
    csv_path = args.csv.resolve() if args.csv else None
    if args.snapshot is not None and args.snapshot < 1:
        parser.error('--snapshot must be a positive number')
    if args.list_only and (args.setup or args.refresh or args.mode or args.save_to or args.csv):
        parser.error('--list only accepts an existing snapshot workspace')
    on_prem = str(Path(args.on_prem).resolve()) if args.on_prem else None
    output = args.output.resolve() if args.output else workspace_dir() / 'output'
    save_to = args.save_to.resolve() if args.save_to else None
    index_file = output / 'snapshot-index.json'
    if args.list_only or (args.snapshot is not None and not (args.refresh or args.setup)):
        if not index_file.exists():
            parser.error(f'No saved snapshot index at {index_file}. Capture an inventory first.')
    if index_file.exists() and not (args.refresh or args.setup):
        from snapshots import open_snapshot
        index = json.loads(index_file.read_text(encoding='utf-8'))
        return open_snapshot(HERE, index, on_prem, output=output, snapshot=args.snapshot,
                             mode=args.mode, list_only=args.list_only, save_to=save_to, csv_path=csv_path, environment=args.environment)
    os.chdir(workspace_dir())
    if not args.in_environment:
        interpreter = ensure_environment()
        command = [str(interpreter), str(HERE / 'cloud_inventory.py'), '--in-environment',
                   '--home-region', args.home_region, '--output', str(output)]
        if args.environment:
            command += ['--environment', args.environment]
        if csv_path:
            command += ['--csv', str(csv_path)]
        if save_to:
            command += ['--save-to', str(save_to)]
        if args.snapshot is not None:
            command += ['--snapshot', str(args.snapshot)]
        if args.mode:
            command += ['--mode', args.mode]
        if on_prem:
            command += ['--on-prem', on_prem]
        if args.setup:
            command.append('--setup')
        if args.refresh:
            command.append('--refresh')
        result = subprocess.run(command)
        return result.returncode
    return wizard(args.home_region, on_prem, args.setup, args.refresh, output=output,
                  snapshot=args.snapshot, mode=args.mode, save_to=save_to, csv_path=csv_path, environment=args.environment)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (Exception, KeyboardInterrupt) as exc:
        console.text('\n  [FAILED] ' + (str(exc) or 'Cancelled'), 'red')
        console.info('No deployment/apply commands were executed. Fix the reported step and rerun.')
        sys.exit(1)
