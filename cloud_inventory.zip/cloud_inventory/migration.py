"""Build evidence-backed migration artifacts from cloud and optional on-prem inventories."""
import json
from pathlib import Path
import re

from terraform_json import normalize_azure


AZURE_LINKS = {
    'microsoft.compute/virtualmachines': [
        ('uses NIC', 'networkProfile.networkInterfaces.*.id'),
        ('uses OS disk', 'storageProfile.osDisk.managedDisk.id'),
        ('uses data disk', 'storageProfile.dataDisks.*.managedDisk.id'),
    ],
    'microsoft.network/networkinterfaces': [
        ('in subnet', 'ipConfigurations.*.properties.subnet.id'),
        ('uses public IP', 'ipConfigurations.*.properties.publicIPAddress.id'),
        ('uses NSG', 'networkSecurityGroup.id'),
    ],
    'microsoft.network/virtualnetworks/subnets': [
        ('uses NSG', 'networkSecurityGroup.id'),
        ('uses route table', 'routeTable.id'),
        ('uses NAT gateway', 'natGateway.id'),
    ],
    'microsoft.network/virtualnetworks': [
        ('peers with', 'virtualNetworkPeerings.*.properties.remoteVirtualNetwork.id'),
    ],
}
AWS_LINKS = {
    'ec2:instance': [('in subnet', 'SubnetId'), ('uses security group', 'SecurityGroups.*.GroupId'),
                     ('uses volume', 'BlockDeviceMappings.*.Ebs.VolumeId')],
    'ec2:subnet': [('in VPC', 'VpcId')],
    'ec2:security-group': [('in VPC', 'VpcId')],
    'ec2:route-table': [('in VPC', 'VpcId')] + [
        ('routes to', 'Routes.*.' + field) for field in (
            'GatewayId', 'NatGatewayId', 'TransitGatewayId', 'VpcPeeringConnectionId',
            'NetworkInterfaceId', 'EgressOnlyInternetGatewayId', 'InstanceId',
        )
    ],
    'ec2:nat-gateway': [('in subnet', 'SubnetId'), ('uses elastic IP', 'NatGatewayAddresses.*.AllocationId')],
    'ec2:internet-gateway': [('attached to VPC', 'Attachments.*.VpcId')],
    'elbv2:load-balancer': [('in subnet', 'AvailabilityZones.*.SubnetId'), ('in VPC', 'VpcId')],
    'rds:db-instance': [('in VPC', 'DBSubnetGroup.VpcId'), ('in subnet', 'DBSubnetGroup.Subnets.*.SubnetIdentifier')],
}


def values(node, parts, evidence='properties'):
    if not parts:
        if isinstance(node, str) and node and node != 'local':
            yield node, evidence
        return
    head, *tail = parts
    if head == '*' and isinstance(node, list):
        for index, child in enumerate(node):
            yield from values(child, tail, f'{evidence}[{index}]')
    elif isinstance(node, dict) and head in node:
        yield from values(node[head], tail, f'{evidence}.{head}')


def write_migration(root, provider, resources, selected, on_prem_path, dump):
    rows = normalize_azure(resources) if provider == 'azure' else resources
    key = str.lower if provider == 'azure' else str
    cloud = {key(row['id']): row for row in rows}
    edges = []
    route_tables = {}
    for row in rows:
        if row['type'].lower() == 'ec2:route-table':
            properties = row.get('properties') or {}
            for index, association in enumerate(properties.get('Associations') or []):
                association_key = association.get('SubnetId')
                if not association_key and association.get('Main'):
                    association_key = properties.get('VpcId')
                if association_key:
                    route_tables[association_key] = (row['id'], index)

    for row in rows:
        kind = row['type'].lower()
        properties = row.get('properties') or {}
        links = AZURE_LINKS if provider == 'azure' else AWS_LINKS
        for relation, path in links.get(kind, []):
            for target, evidence in values(properties, path.split('.')):
                edges.append({'source': row['id'], 'relationship': relation, 'target': target,
                              'evidence': evidence, 'resolved': key(target) in cloud})
        if kind == 'microsoft.network/virtualnetworks/subnets' and '/subnets/' in row['id'].lower():
            parent = row['id'].rsplit('/', 2)[0]
            edges.append({'source': row['id'], 'relationship': 'in VNet', 'target': parent,
                          'evidence': 'ARM resource ID', 'resolved': key(parent) in cloud})
        if kind == 'ec2:subnet':
            match = route_tables.get(row['id']) or route_tables.get(properties.get('VpcId'))
            if match:
                target, index = match
                edges.append({'source': row['id'], 'relationship': 'uses route table', 'target': target,
                              'evidence': f'{target}:properties.Associations[{index}]', 'resolved': True})
    gaps = []
    workloads = []
    if on_prem_path:
        with Path(on_prem_path).open(encoding='utf-8-sig') as stream:
            source = json.load(stream)
        if not isinstance(source, dict) or not isinstance(source.get('workloads'), list):
            raise ValueError('On-prem inventory must be a JSON object with a workloads array.')
        for workload in source['workloads']:
            if not isinstance(workload, dict) or not isinstance(workload.get('id'), str) or not workload['id'].strip():
                raise ValueError('Each on-prem workload needs a nonempty string id.')
            dependencies = workload.get('depends_on')
            if dependencies is not None and (not isinstance(dependencies, list) or
                                               any(not isinstance(item, str) for item in dependencies)):
                raise ValueError('depends_on must be an array of workload IDs.')
            target = workload.get('target_resource_id')
            if target is not None and not isinstance(target, str):
                raise ValueError('target_resource_id must be a string.')
            workloads.append({'id': workload['id'], 'depends_on': dependencies, 'target_resource_id': target,
                              'target_status': 'found_in_cloud_inventory' if target and key(target) in cloud
                              else 'outside_cloud_inventory' if target else 'unmapped'})
        ids = {item['id'] for item in workloads}
        if len(ids) != len(workloads):
            raise ValueError('On-prem workload IDs must be unique.')
        for item in workloads:
            if item['depends_on'] is None:
                gaps.append({'workload': item['id'], 'issue': 'dependencies_unknown'})
            for dependency in item['depends_on'] or []:
                if dependency not in ids:
                    gaps.append({'workload': item['id'], 'issue': 'dependency_outside_on_prem_inventory',
                                 'dependency': dependency})
            if item['target_status'] != 'found_in_cloud_inventory':
                gaps.append({'workload': item['id'], 'issue': item['target_status']})
    if not workloads:
        gaps.append({'issue': 'on_prem_workload_inventory_missing'})
    gaps.extend({'issue': 'cloud_reference_outside_inventory', **edge} for edge in edges if not edge['resolved'])
    if not cloud:
        gaps.append({'issue': 'cloud_inventory_empty'})

    folder = root / 'migration'
    dump(folder / 'cloud_topology.json', {'provider': provider, 'resources': [
        {field: row[field] for field in ('id', 'type', 'name')} for row in cloud.values()
    ], 'relationships': edges})
    dump(folder / 'migration_plan.json', {
        'provider': provider,
        'status': 'review_required',
        'on_prem_workloads': workloads,
        'terraform_scope': [row['id'] for row in selected],
        'phases': [
            'Confirm on-prem workloads, owners, dependencies, and recovery objectives.',
            'Validate cloud landing zone, connectivity, DNS, identity, and target sizing.',
            'Review Terraform drafts and reconcile state for existing cloud resources.',
            'Pilot data and application migration, then test cutover and rollback.',
            'Schedule production waves after dependency and readiness review.',
        ],
        'gaps': gaps,
    })
    node_ids = {resource_id: f'c{i}' for i, resource_id in enumerate(cloud)}
    lines = ['flowchart TD']
    for resource_id, row in cloud.items():
        label = re.sub(r'[^\w .:/-]', ' ', row['name']).strip()[:90] or row['type']
        lines.append(f'  {node_ids[resource_id]}["{label}"]')
    for edge in edges:
        if edge['resolved']:
            lines.append(f'  {node_ids[key(edge["source"])]} -->|{edge["relationship"]}| {node_ids[key(edge["target"])]}')
    (folder / 'cloud_topology.mmd').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(f'Migration artifacts: {folder.resolve()}')
    return len(gaps)
