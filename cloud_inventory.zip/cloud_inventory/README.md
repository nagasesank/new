# On-prem to Cloud Migration Toolkit

Read Azure/AWS configuration into JSON, then compile that JSON into Terraform resource HCL. Generation is entirely local: no cloud login, SDK, Terraform executable or model/API key is required once JSON is available. Python 3.10+.


## Start here: automatic setup

Run from the extracted project directory with Python 3.10 or later.

```text
python cloud_inventory.py
```

The launcher creates an isolated .venv, installs every pinned dependency from requirements.txt, runs pip check and verifies SDK/parser imports. It uses the project environment instead of modifying your global Python dependencies. During capture, choose one Azure subscription from the enabled subscriptions visible to Azure CLI. For AWS, choose one enabled region per reachable account from the current credentials and configured profiles. Region-scoped capture excludes global IAM and S3 buckets whose region could not be verified. AWS capture uses the first verified profile for each account. The index records resource counts, partial captures, and discovery errors. Save the project and output directory together to reuse local snapshots.

Later runs open the saved index offline. Select a snapshot to generate migration artifacts and Terraform from its JSON. Run `python cloud_inventory.py --refresh` to capture a new batch, or `python cloud_inventory.py --setup` to change cloud or profile preferences. The next setup or refresh checks for changes to requirements.txt. The cloud CLIs handle credentials.

An existing copy without saved preferences runs setup once after this update.

You will see:

```text
CLOUD INVENTORY | SETUP -> LOGIN -> JSON -> TERRAFORM
[1/5] Installing requirements...
[2/5] Checking Azure / AWS CLI...
[3/5] Logging in to selected clouds...
[4/5] Capturing accessible accounts and subscriptions...
Select snapshot number, or Enter to exit:
```

Choose both/azure/aws (default both). Existing CLIs are verified and reused. A missing CLI offers installation in the same wizard. Windows uses WinGet package IDs Microsoft.AzureCLI / Amazon.AWSCLI, refreshing this process's PATH after installation. macOS supports installation through an existing Homebrew. Linux and other platforms require a vendor CLI installation first; no privileged remote shell scripts are run. AWS CLI v2 is required for guided setup.

CLI installers can invoke their normal UAC/admin prompts. Windows requires WinGet/App Installer; CLI installation is not a pip dependency. If corporate policy, proxies, package-manager availability or permissions block installation, the wizard stops with a clear error instead of claiming success. No software can guarantee that every external installation succeeds on every machine.

Login stage:

- Azure: existing login, browser login or device-code login; optional tenant ID/domain. When no cached subscriptions exist, browser login is suggested. ARM token expiry is checked without printing/saving token values.
- AWS: select an existing profile or enter a new profile; choose existing, sso, setup-sso or configure. SSO setup/login and access-key configuration are handled directly by the official CLI. Installer logs do not capture login prompts. Keys are never requested by this chat or written by the application; normal `aws configure` stores credentials in the standard local AWS files.
- Every non-skipped selected cloud must authenticate before the export question. A failed login offers retry or explicit skip; otherwise export stops.

After setup, discovery prompts for the Azure subscription and AWS region and writes `output/snapshot-index.json`. Each batch keeps its own inventory and capture report.

Dependency/installer output is stored under setup_logs/ for troubleshooting; application credentials are not logged there. Setup requires Internet connectivity for packages/installers/sign-in. JSON-only generation still works without installing anything.

To install Python dependencies manually instead of the launcher:

```text
python -m pip install -r requirements.txt
python -m pip check
```

Pinned requirements were installed and import-checked in a fresh isolated build environment. This is separate from live Windows installer and cloud-login verification, which was not available in the build environment.

## Output options

```text
python cloud_inventory.py -h
python cloud_inventory.py --list
python cloud_inventory.py --snapshot 1 --mode export
python cloud_inventory.py --snapshot 1 --mode generate --save-to ./terraform-review
python cloud_inventory.py --refresh --output ./cloud-capture
```

`--output` selects the snapshot workspace. Use the same directory to list or reuse its snapshots. `--save-to` changes only where derived files are written. `--mode export` saves inventory JSON, migration plan and Mermaid topology. `--mode generate` adds Terraform and its generation reports. Both modes process all resources in the selected snapshot. Omit `--mode` to choose resource scope and action interactively.

## Client CSV and JSON requests

For the guided flow, run `python cloud_inventory.py`, select a snapshot and choose generate. The tool asks whether you have a client CSV or JSON file. Enter its path or continue with the saved inventory. Use `--overrides` for scripted runs.

Use UTF-8 CSV with one row per resource. Required columns are `action`, `resource_id`, and `attributes_json`. Optional columns for creation are `name`, `resource_type`, `region` (AWS), `location` and `resource_group` (Azure). Values in `attributes_json` use the inventory field names, such as AWS `properties.CidrBlock`. Quote the JSON column using standard CSV escaping.

```csv
action,resource_id,name,resource_type,region,attributes_json
create,planned-vpc,client-vpc,ec2:vpc,us-east-1,"{""properties"":{""CidrBlock"":""10.42.0.0/16""}}"
change,vpc-existing,,,,"{""properties"":{""EnableDnsSupport"":true}}"
```

```text
python cloud_inventory.py --snapshot 1 --overrides client.csv --mode generate --save-to ./review
python cloud_inventory.py --snapshot 1 --overrides client.json --mode generate --save-to ./review
python cloud_inventory.py --provider aws --account-id ACCOUNT_ID --csv-only --csv creates.csv --non-interactive
python cloud_inventory.py --provider azure --subscription SUBSCRIPTION_ID --csv-only --csv creates.csv --non-interactive
```

For JSON, pass a `requests` array with the same fields and an `attributes` object in place of `attributes_json`. Both formats apply to a copy of the selected inventory before Terraform and tfvars generation. Omit `--overrides` to generate directly from saved inventory values.

Create rows require supported inventory types and unique IDs. Azure IDs must be target ARM IDs in the selected subscription. AWS planned IDs are local references. Use the same planned ID in dependent rows. Change rows must match the selected inventory and keep identity columns blank. Nested objects merge and arrays replace. New resources omit Terraform import blocks. Existing resources retain import blocks. The compiler uses supported mappings from the existing Azure and AWS emitters. Review Terraform output against the CSV before applying. Avoid storing secret values in CSV or generated HCL.

## Publish reviewed Terraform to Git

Copy the intended Terraform files into a checked-out branch and commit them after review. The push action requires a clean working tree and pushes the current branch to the named remote.

```text
python cloud_inventory.py --git-push ./review-repo --remote origin
```

For deployment, initialize the generated Terraform root with the intended backend and credentials. Create and inspect a saved Terraform plan, then apply the reviewed plan through your normal deployment process.

## Migration workflow

Use the setup wizard to discover the current cloud landing zone. For a cloud inventory you already exported, use Python directly.

```text
python cloud_inventory.py --provider azure --inventory /path/to/cloud-inventory.json --scope all --non-interactive
```

Use `--provider aws` for an AWS export. Include `--on-prem /path/to/on-prem-inventory.json` to attach your source inventory to either command or to the setup wizard.

The on-prem JSON is an object with a `workloads` array. Each entry requires a unique string `id`. Optional `depends_on` lists other workload IDs. An empty list records that the inventory declares no dependencies. Omit the field when dependencies are unknown. Optional `target_resource_id` links the workload to an Azure ARM resource ID or AWS inventory resource ID. The report indicates whether that target appears in the export. This match confirms inventory presence only.

Each run writes:

- `migration/cloud_topology.json` and `migration/cloud_topology.mmd` with observed cloud relationships and evidence paths.
- `migration/migration_plan.json` with source-to-target mappings, missing inventory, unresolved references, and stages for review.
- `terraform-infra/` with Terraform drafts for the selected cloud inventory when generation is requested.

Cloud discovery describes resources that already exist. New target sizing, application dependencies, migration waves, and cutover decisions require source inventory and engineering review. The migration plan records gaps when source data is absent.

## Interactive flow

```text
python cloud_inventory.py
```

1. Choose azure/aws.
2. Choose cloud (export from authenticated cloud) or json (existing snapshot).
3. For json: enter the file path. No CLI/login is invoked.
4. For cloud: guided login/profile selection, account/subscription/region selection, then JSON export.
5. Choose all, resource types, or individual resource IDs; Azure also supports groups. Type selection supports numbered multi-select followed by individual-resource selection.
6. Save selection/resources.json.
7. Choose generate (default) or export. Generation always uses the selected JSON, regardless of where it came from.

--generate is retained for compatibility and forces generation without the next-action question. It NEVER runs terraform plan. --export-only saves snapshots and selection without Terraform. Non-interactive runs generate by default unless --export-only is supplied.

## Cloud export prerequisites

Azure: Azure CLI and a logged-in Reader identity. AWS: boto3 and a valid SDK credential chain. Interactive cloud login uses the relevant CLI; non-interactive AWS collection uses boto3 directly.

```text
python -m pip install -r requirements.txt
```

Windows CLI installs if needed, then reopen the terminal:

```text
winget install --exact --id Microsoft.AzureCLI
winget install --exact --id Amazon.AWSCLI
```

Azure guided export and generation:

```text
python cloud_inventory.py --provider azure
```

Choose cloud; existing/browser/device sign-in; subscription; detailed reads; selection; generate. For scripted use, authenticate first:

```text
az login
python cloud_inventory.py --provider azure --subscription YOUR-SUBSCRIPTION-UUID --details --scope all --non-interactive
```

AWS guided flow offers existing profiles, existing credentials/SSO login/SSO profile setup, identity verification and regions. Example scripted use:

```text
aws sso login --profile migration-readonly
python cloud_inventory.py --provider aws --profile migration-readonly --account-id YOUR-12-DIGIT-ACCOUNT-ID --regions ap-south-1 --scope all --non-interactive
```

Without --regions, AWS scans enabled regions. With --account-id, a mismatched identity aborts before discovery. Commercial AWS only. --services limits AWS collectors; e.g. --services ec2 s3. --home-region changes the region-discovery/global endpoint (default us-east-1).

Optional export-only:

```text
python cloud_inventory.py --provider azure --subscription YOUR-SUBSCRIPTION-UUID --details --scope all --export-only --non-interactive
```

## JSON inputs

Azure: array of ARM/ARG resource objects with id, name, type and properties; subscription inferred from ARM IDs. ARM location, sku, kind, resourceGroup, tags and embedded subnet data are used where mapped. An object wrapping the array in data or resources is also accepted. ARG table-format rows require conversion to object-array first.

AWS: the normalized array exported by this program, with provider="aws", account_id, region, type, id, name and properties. Raw arbitrary aws cli command responses are NOT automatically equivalent to this schema. Use this collector or normalize to the schema above. All rows must belong to one account/subscription per run.

Subscription/account flags may be passed to enforce the expected scope. No input JSON is executed. Literal Terraform template sequences in exported strings are escaped.

## JSON-to-HCL emitter coverage

| Cloud | Emits Terraform resource blocks |
| --- | --- |
| Azure | Resource groups, VNets, embedded/standalone subnets, NSGs with inline rules, public IPs, NICs/IP configurations, NSG associations, storage accounts, user-assigned identities, managed disks, Linux/Windows VMs |
| AWS networking | VPCs, subnets, security groups with rules, internet gateways, route tables/routes/subnet associations, EIPs, NAT gateways |
| AWS compute/storage | EC2 instances, EBS volumes, S3 buckets plus exported versioning/encryption/public-access-block/policy, ECR repositories |
| AWS IAM/monitoring | IAM roles/trust documents, local managed-policy documents, CloudWatch log groups |

Azure VMs require a known Linux/Windows OS type; attached existing-OS-disk VM mode is explicitly unsupported. Basic mappings use an allowlist of fields, not every possible provider option. Unsupported types are retained in JSON and reported, never converted into fake generic resource blocks.

References to emitted resources in the SAME Terraform root become HCL references. Dependencies outside selected scope become required variables; their original IDs are retained in generation_report.json. AWS roots are isolated per region/global; cross-root wiring is manual.

Required missing inputs have variables with NO default. terraform.tfvars.example lists null placeholders for review; replace them with real values before use. Passwords are never recovered from cloud inventory or copied into HCL; use sensitive variables. A syntactically valid file does not imply that required inputs or provider-specific validation have been resolved.

## Discovery coverage is broader than emitter coverage

AWS discovery currently covers EC2 networking/instances/volumes; S3 configuration; IAM roles/policy references and local policy documents; RDS instances/clusters; Lambda metadata; DynamoDB; ELBv2; EKS/ECS clusters; ECR; Logs; CloudFormation stacks/membership hints. Some discovered types (RDS/Lambda/DynamoDB/ELB/EKS/ECS/CloudFormation) intentionally lack JSON emitters in v4 and appear in unsupported reports.

Azure uses paginated ARG discovery and optional generic ARM detail reads. It does not enumerate all governance objects, every child type, secret payloads or data-plane contents. ARG is permission-filtered and eventually consistent. Read success does not prove a complete subscription snapshot.

AWS is also a documented collector set, not an all-service export. API Gateway, WAF, Route 53, CloudFront, queue/topic services and many children are not implemented. IAM inline policy CONTENTS/attachments and workload artifacts need separate collection/mapping. aws_discovery_policy.json is a discovery-permissions example for review, not a policy the tool attaches. SCPs and other policies can still deny reads.

## Output files

```text
output/<cloud>/<scope>/<run>/
  discovery/resources.json
  discovery/by_type/*.json
  discovery/type_index.json
  selection/resources.json
  coverage.json
  errors.json
  terraform-infra/
    environments/
      dev/                       # Default; select uat or prod with --environment
        main.tf                  # AWS places root files under <region>/
        providers.tf
        variables.tf
        terraform.tfvars
        imports.tf
        generation_report.json
      uat/
      prod/
    modules/
      azure/
        networking/networking.tf
        identity/iam.tf
      aws/
        networking/networking.tf
        compute/compute.tf
      shared/
        tags/
        naming/
    cloud-infra/
      foundation/
    policies/
    scripts/                     # Inventory tool, Python support files and requirements
    infra-pipelines/
      templates/
```

Latest-export pointers are stored at output/<cloud>/<scope>/latest_export.json. They point to saved snapshots, not proof of successful completion; inspect coverage.json/errors.json. --output changes the common output base. All output generation uses new run directories and does not overwrite an existing Terraform root.

Each run populates only the selected environment and the service modules needed by its inventory. Run Terraform from `terraform-infra/environments/<environment>/` for Azure or `terraform-infra/environments/<environment>/<region>/` for AWS. Multi-region AWS runs put each module's files in a region subdirectory to keep their configurations separate. The generated repository includes the runnable inventory tool under scripts/ and the AWS discovery-policy example under policies/. Run python scripts/cloud_inventory.py -h from the generated repository root. Shared and pipeline folders are reserved for repository-specific configuration.

```text
python cloud_inventory.py --snapshot 1 --mode generate --environment uat
```

The root passes tfvars values into service modules. Provider scope and import IDs stay in the root configuration. Imports use module-qualified addresses. If earlier flat output is already in Terraform state, review state address migration before using these module roots. Generation produces local files for review.

## Review and limitations

This creates an adoption draft, not an exact clone guarantee. Unmapped optional settings may be absent; provider defaults can produce changes. Check report warnings and compare against the complete exported JSON. Storage ACLs, VM data-disk/extension/identity details, EBS attachment/root-volume ownership, many IAM bindings and service children need additional mapping. Best-practice changes and module refactoring should follow baseline reconciliation rather than alter production configuration silently.

The compiler does not run Terraform or any SDK. Optional local checks, if Terraform and provider download access are available:

```text
terraform -chdir=PATH-TO-A-TERRAFORM-ROOT init -backend=false
terraform -chdir=PATH-TO-A-TERRAFORM-ROOT fmt -recursive
terraform -chdir=PATH-TO-A-TERRAFORM-ROOT validate
```

These are manual commands, not part of generation. No plan/apply is required to obtain resource HCL. Schema validation is distinct from syntax parsing; provider schemas evolve. Future state adoption requires resolving existing CloudFormation/CDK ownership and reviewing a real plan separately.

Keep exports/reports/state private. Known AWS sensitive fields are redacted, but tags and arbitrary properties can still be sensitive. Azure exports are not globally redacted. Generated tfvars examples contain no secret values; do not commit filled credentials or variable files. CLI login/setup changes normal local auth caches/config, not cloud infrastructure.

Exit codes: 0 generated/exported within documented limits; 2 read failures or unsupported discovered types; 1 fatal error. Required input variables are recorded in reports but do not alone cause exit code 2. Do not mistake exit code 0 for production deployability.

## Tests

Standard tests (optional syntax-parser test skips if parser absent):

```text
python -m unittest discover -v
```

Include HCL syntax parsing:

```text
python -m pip install -r requirements-dev.txt
python -m unittest discover -v
```

The packaged tests cover CLI setup and cloud inventory collectors. Azure and AWS migration artifacts were checked against local inventory fixtures before packaging. Live collection and Terraform provider validation require the target environment.

## Sources

- https://learn.microsoft.com/en-us/azure/governance/resource-graph/overview
- https://learn.microsoft.com/cli/azure/authenticate-azure-cli-interactively
- https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-sso.html
- https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs
- https://developer.hashicorp.com/terraform/language/import

Setup installation references:
- https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows?pivots=winget
- https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
