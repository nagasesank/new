import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
import aws_inventory as aws


class Paginator:
    def __init__(self, pages):
        self.pages = pages
    def paginate(self, **kwargs):
        yield from self.pages


class AwsTests(unittest.TestCase):
    def test_paginator_collects_every_page(self):
        client = Mock()
        client.can_paginate.return_value = True
        client.get_paginator.return_value = Paginator([{'Vpcs': [{'VpcId': 'vpc-1'}]}, {'Vpcs': [{'VpcId': 'vpc-2'}]}])
        rows = list(aws.pages(client, 'describe_vpcs', 'Vpcs'))
        self.assertEqual([r['VpcId'] for r in rows], ['vpc-1', 'vpc-2'])

    def test_unhandled_token_fails_instead_of_truncating(self):
        client = Mock()
        client.can_paginate.return_value = False
        client.list_tables.return_value = {'TableNames': ['a'], 'NextToken': 'more'}
        with self.assertRaises(RuntimeError):
            list(aws.pages(client, 'list_tables', 'TableNames'))

    def test_redaction(self):
        raw = {'Environment': {'Variables': {'KEY': 'secret'}},
               'nested': [{'Password': 'secret'}], 'ResponseMetadata': {'RequestId': 'id'}, 'VpcId': 'vpc-1'}
        result = aws.clean(raw)
        self.assertNotIn('secret', json.dumps(result))
        self.assertEqual(result['VpcId'], 'vpc-1')
        self.assertNotIn('ResponseMetadata', result)

    def test_access_denial_reported_and_continues(self):
        class Denied(Exception):
            response = {'Error': {'Code': 'AccessDenied'}}
        collector = aws.Collector(None, '123456789012', None, Path('.'))
        def denied():
            raise Denied('sensitive server response')
        self.assertIsNone(collector.record('ec2', 'us-east-1', 'describe_vpcs', denied))
        self.assertEqual(collector.errors[0]['error_code'], 'AccessDenied')
        self.assertEqual(collector.record('ec2', 'us-east-1', 'describe_subnets', lambda: []), [])
        self.assertEqual(collector.coverage[-1]['status'], 'success')
        self.assertNotIn('sensitive', json.dumps(collector.errors))

    def test_ec2_reservations_flattened_and_other_reads_continue(self):
        session = Mock()
        ec2 = Mock()
        session.client.return_value = ec2
        ec2.can_paginate.return_value = True
        def paginator(operation):
            if operation == 'describe_instances':
                return Paginator([{'Reservations': [{'Instances': [{'InstanceId': 'i-1', 'Tags': [{'Key': 'Name', 'Value': 'app'}]}]}]}])
            key = next(s[2] for s in aws.SPECS if s[1] == operation)
            return Paginator([{key: []}])
        ec2.get_paginator.side_effect = paginator
        c = aws.Collector(session, '123456789012', None, Path('.'))
        c.regional(['us-east-1'], ['ec2'])
        self.assertEqual(len(c.resources), 1)
        self.assertEqual(c.resources[0]['name'], 'app')
        self.assertEqual(c.resources[0]['id'], 'i-1')
        self.assertTrue(all(e['status'] == 'success' for e in c.coverage))

    def test_unknown_bucket_region_never_generates_wrong_import(self):
        client = Mock()
        client.can_paginate.return_value = True
        client.get_paginator.return_value = Paginator([{'Buckets': [{'Name': 'demo'}]}])
        client.get_bucket_location.side_effect = RuntimeError('denied')
        session = Mock()
        session.client.return_value = client
        c = aws.Collector(session, '123456789012', None, Path('.'))
        c.buckets('us-east-1', ['us-east-1'])
        self.assertEqual(c.resources[0]['type'], 's3:bucket-region-unknown')
        from terraform_json import AWS_TYPES
        self.assertNotIn(c.resources[0]['type'], AWS_TYPES)

    def test_offline_scope_and_path_validation(self):
        valid = {'provider': 'aws', 'account_id': '123456789012', 'id': 'vpc-1', 'name': 'vpc', 'type': 'ec2:vpc', 'region': 'us-east-1'}
        aws.validate_inventory([valid], '123456789012')
        for changed in ({'account_id': '000000000000'}, {'region': '../../evil'}, {'provider': 'azure'}):
            with self.assertRaises(ValueError):
                aws.validate_inventory([{**valid, **changed}], '123456789012')

    def test_all_collectors_are_read_operations(self):
        self.assertTrue(all(s[1].startswith(('describe_', 'list_', 'get_')) for s in aws.SPECS))


    def test_missing_s3_configuration_is_not_permission_failure(self):
        class Missing(Exception):
            response = {'Error': {'Code': 'NoSuchBucketPolicy'}}
        def absent():
            raise Missing()
        c = aws.Collector(None, '123456789012', None, Path('.'))
        result = c.record('s3', 'us-east-1', 'get_bucket_policy', absent)
        self.assertEqual(result['configuration_status'], 'not_configured')
        self.assertEqual(c.errors, [])
        self.assertEqual(c.coverage[0]['status'], 'not_configured')

if __name__ == '__main__':
    unittest.main()
