"""Apply client resource requests to a copy of the normalized inventory."""
import csv
import json
import re
from pathlib import Path

from terraform_json import AWS_TYPES, AZURE_TYPES, normalize_azure


COLUMNS = {'action', 'resource_id', 'name', 'resource_type', 'region', 'location',
           'resource_group', 'attributes_json'}
MUTABLE = {'properties', 'tags', 'sku', 'kind'}


def merge(base, patch):
    result = dict(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge(result[key], value)
        else:
            result[key] = value
    return result


def read_requests(path):
    if Path(path).suffix.lower() == '.json':
        data = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        requests = data.get('requests') if isinstance(data, dict) else data
        if not isinstance(requests, list):
            raise ValueError('JSON overrides require a requests array.')
        for index, request in enumerate(requests, 1):
            if not isinstance(request, dict) or 'attributes' not in request or 'attributes_json' in request:
                raise ValueError(f'JSON request {index}: expected an object with attributes.')
            row = dict(request)
            row['attributes_json'] = json.dumps(row.pop('attributes'))
            yield index, row
        return
    if Path(path).suffix.lower() != '.csv':
        raise ValueError('Client overrides must use a .csv or .json file.')
    with open(path, encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        headers = reader.fieldnames or []
        if not {'action', 'resource_id', 'attributes_json'}.issubset(headers):
            raise ValueError('CSV requires action, resource_id and attributes_json headers.')
        if len(headers) != len(set(headers)) or set(headers) - COLUMNS:
            raise ValueError('CSV contains duplicate or unsupported headers.')
        for record in reader:
            yield reader.line_num, record


def apply_requests(path, provider, scope, rows):
    key = str.lower if provider == 'azure' else str
    original = normalize_azure(rows) if provider == 'azure' else rows
    resources = {key(row['id']): row for row in original}
    if len(resources) != len(original):
        raise ValueError('Client overrides require unique resource IDs in the inventory.')
    requested = set()
    types = AZURE_TYPES if provider == 'azure' else AWS_TYPES
    for line_number, record in read_requests(path):
        try:
            if set(record) - COLUMNS or not {'action', 'resource_id', 'attributes_json'}.issubset(record) or any(
                        not isinstance(value, str) for value in record.values()):
                raise ValueError('Column count does not match the header.')
            row = {field: value.strip() for field, value in record.items()}
            resource_id = row['resource_id']
            resource_key = key(resource_id)
            action = row['action'].lower()
            if not resource_id or resource_key in requested:
                raise ValueError('Each request must have a unique resource_id.')
            attributes = json.loads(row['attributes_json'])
            if not isinstance(attributes, dict) or set(attributes) - MUTABLE:
                raise ValueError('attributes_json supports properties, tags, sku and kind.')
            for field in ('properties', 'sku'):
                if field in attributes and not isinstance(attributes[field], dict):
                    raise ValueError(f'{field} must be a JSON object.')
            if provider == 'aws':
                if set(attributes) - {'properties', 'tags'}:
                    raise ValueError('AWS attributes support properties and tags.')
                if 'tags' in attributes:
                    tags = attributes.pop('tags')
                    if not isinstance(tags, dict) or any(not isinstance(v, str) for v in tags.values()):
                        raise ValueError('AWS tags must be a JSON object of string values.')
                    attributes.setdefault('properties', {})['Tags'] = tags
            if action == 'change':
                if resource_key not in resources:
                    raise ValueError('Change target was not found in the inventory.')
                if any(row.get(field) for field in ('name', 'resource_type', 'region', 'location', 'resource_group')):
                    raise ValueError('Use attributes_json for changes. Identity columns must be blank.')
                resource = resources[resource_key]
            elif action == 'create':
                kind = row.get('resource_type', '').lower()
                if resource_key in resources or not row.get('name') or kind not in types:
                    raise ValueError('Create requires an unused ID, name and supported resource_type.')
                resource = {'id': resource_id, 'name': row['name'], 'type': kind, 'properties': {}}
                if provider == 'azure':
                    if not resource_key.startswith(f'/subscriptions/{scope.lower()}/'):
                        raise ValueError('Azure create needs a target ARM ID in the selected subscription.')
                    resource.update(location=row.get('location', ''), resourceGroup=row.get('resource_group', ''))
                else:
                    region = row.get('region', '')
                    if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', region):
                        raise ValueError('AWS create requires a region or global.')
                    resource.update(provider='aws', account_id=scope, region=region)
            else:
                raise ValueError('action must be create or change.')
            if resource['type'].lower() not in types:
                raise ValueError('No Terraform emitter exists for this resource type.')
            resources[resource_key] = {**merge(resource, attributes), '_csv_action': action}
            requested.add(resource_key)
        except ValueError as exc:
            raise ValueError(f'Client request {line_number}: {exc}') from exc
    if not requested:
        raise ValueError('Client file contains no resource requests.')
    return list(resources.values())
