"""Capture cloud inventory once and index local copies for offline use."""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from tempfile import NamedTemporaryFile
import uuid

from workflow import aws_identity


def collect(project, setup, home_region, output=None):
    output = output or project / 'output'
    batch = output / 'snapshot-batches' / uuid.uuid4().hex
    batch.mkdir(parents=True, mode=0o700)
    entries, failures, targets = [], [], []

    def failed(provider, scope, exc):
        failures.append({'provider': provider, 'scope': scope, 'error': str(exc)})

    if 'azure' in setup['providers']:
        from cloud_inventory import choose

        try:
            subscriptions = json.loads(subprocess.check_output(
                [shutil.which('az') or 'az', 'account', 'list', '--output', 'json',
                 '--only-show-errors'], text=True, timeout=90))
            enabled = [sub for sub in subscriptions if sub.get('state') == 'Enabled']
            print('Select Azure subscription for this capture:')
            subscription = choose(enabled, lambda sub: f"{sub.get('name', sub['id'])} ({sub['id']})")
            scope = str(uuid.UUID(subscription['id']))
            targets.append(('azure', scope, subscription.get('name', scope),
                            ['--subscription', scope, '--details'], subscription.get('tenantId')))
        except (OSError, RuntimeError, ValueError, KeyError, subprocess.SubprocessError) as exc:
            failed('azure', 'subscription discovery', exc)
    if 'aws' in setup['providers']:
        profiles = [setup.get('profile')]
        try:
            profiles += subprocess.check_output(
                [shutil.which('aws') or 'aws', 'configure', 'list-profiles'],
                text=True, timeout=30).split()
        except (OSError, subprocess.SubprocessError) as exc:
            failed('aws', 'profile discovery', exc)
        seen = set()
        for profile in dict.fromkeys(profiles):
            try:
                scope = aws_identity(profile, home_region)['Account']
                if not re.fullmatch(r'[0-9]{12}', scope):
                    raise ValueError('Invalid AWS account ID')
                if scope in seen:
                    continue
                seen.add(scope)
                args = ['--account-id', scope, '--home-region', home_region, '--choose-region']
                if profile:
                    args += ['--profile', profile]
                targets.append(('aws', scope, profile or 'default credentials', args, None))
            except (OSError, RuntimeError, ValueError, KeyError, subprocess.SubprocessError) as exc:
                failed('aws', profile or 'default credentials', exc)
    for provider, scope, label, args, tenant in targets:
        print(f'Capturing {provider.upper()} {label} ({scope})...', flush=True)
        result = subprocess.run([sys.executable, str(project / 'cloud_inventory.py'), '--provider',
                                 provider, '--output', str(batch), '--scope', 'all', '--non-interactive',
                                 '--export-only', *args])
        if result.returncode not in (0, 2):
            failed(provider, scope, f'Export exited with code {result.returncode}')
            continue
        try:
            pointer = json.loads((batch / provider / scope / 'latest_export.json').read_text())
            inventory = Path(pointer['inventory_file'])
            rows = json.loads(inventory.read_text(encoding='utf-8'))
            coverage = json.loads((inventory.parent.parent / 'coverage.json').read_text(encoding='utf-8'))
            regions = coverage.get('regions', [])
            entries.append({'regions': regions, 'provider': provider, 'scope': scope, 'label': label, 'tenant': tenant,
                            'inventory': str(inventory.relative_to(output)), 'resources': len(rows),
                            'partial': result.returncode == 2})
        except (OSError, ValueError, KeyError) as exc:
            failed(provider, scope, exc)
    index = {'captured_at': datetime.now(timezone.utc).isoformat(), 'snapshots': entries, 'failures': failures}
    (batch / 'index.json').write_text(json.dumps(index, indent=2), encoding='utf-8')
    path = output / 'snapshot-index.json'
    if entries or not path.exists() or not failures:
        with NamedTemporaryFile(mode='w', dir=output, encoding='utf-8', delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(index, stream, indent=2)
        try:
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)
    return index, batch / 'index.json'


def open_snapshot(project, index, on_prem, *, output=None, snapshot=None, mode=None,
                  list_only=False, save_to=None, csv_path=None, environment=None):
    output = output or project / 'output' 
    entries = index['snapshots']
    azure_count = sum(entry['provider'] == 'azure' for entry in entries)
    print(f"Saved inventory from {index['captured_at']}")
    print(f'{azure_count} Azure subscription snapshots | {len(entries) - azure_count} AWS account snapshots')
    if index['failures']:
        print(f"{len(index['failures'])} capture errors. See snapshot-index.json for details.")
    for number, entry in enumerate(entries, 1):
        status = ' | partial' if entry['partial'] else ''
        region = f" | {', '.join(entry.get('regions', []))}" if entry.get('regions') else ''
        print(f"{number}. {entry['provider'].upper()} {entry['label']} ({entry['scope']}) | "
              f"{entry['resources']} resources{region}{status}")
    if list_only:
        return 0
    if not entries:
        print('No snapshots available. Check the capture report and use --refresh to retry.')
        return 2
    answer = str(snapshot) if snapshot is not None else input('Select snapshot number, or Enter to exit: ').strip()
    if not answer:
        return 0
    if not answer.isdecimal() or not 1 <= int(answer) <= len(entries):
        raise ValueError('Select a snapshot number shown in the list.')
    entry = entries[int(answer) - 1]
    provider = entry['provider']
    identity = '--subscription' if provider == 'azure' else '--account-id'
    command = [sys.executable, str(project / 'cloud_inventory.py'), '--provider', provider,
               '--inventory', str(output / entry['inventory']), identity, entry['scope'],
               '--output', str(save_to or output)]
    if environment:
        command += ['--environment', environment]
    if mode:
        command += ['--non-interactive', '--scope', 'all',
                    '--export-only' if mode == 'export' else '--generate']
    if provider == 'azure' and entry['tenant']:
        command += ['--tenant', entry['tenant']]
    if csv_path:
        command += ['--csv', str(csv_path)]
    if on_prem:
        command += ['--on-prem', on_prem]
    return subprocess.run(command).returncode
