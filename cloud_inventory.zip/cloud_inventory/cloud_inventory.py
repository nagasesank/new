#!/usr/bin/env python3
"""Read-only Azure/AWS discovery and JSON-only Terraform HCL generation.
Python 3.10+. Cloud CLI required only for live discovery/login, never for JSON generation.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

AZ = shutil.which('az')


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
    try:
        path.chmod(0o600)
    except OSError:
        pass


def execute(args, retries=0):
    for attempt in range(retries + 1):
        result = subprocess.run(args, capture_output=True, text=True, timeout=300)
        if result.returncode == 0:
            return result.stdout
        message = result.stderr.strip() or result.stdout.strip()
        if attempt < retries and any(s in message.lower() for s in ('429', 'throttl', '503', 'temporar')):
            time.sleep(min(2 ** attempt, 16))
            continue
        raise RuntimeError(message[:1500])


def az(*args):
    if not AZ:
        raise RuntimeError('Azure CLI missing. Install it and run az login first.')
    return json.loads(execute([AZ, *args, '--only-show-errors', '--output', 'json'], retries=3))


def choose(items, label):
    if not items:
        raise RuntimeError('No selectable items found.')
    for i, item in enumerate(items, 1):
        print(f'  {i}. {label(item)}')
    while True:
        answer = input('Select number: ').strip()
        if answer.isdigit() and 1 <= int(answer) <= len(items):
            return items[int(answer) - 1]
        print('Enter a valid number.')


def graph(subscription, query, page_call=None):
    rows, seen = [], set()
    token = None
    while True:
        options = {'$top': 1000, 'resultFormat': 'objectArray'}
        if token:
            options['$skipToken'] = token
        body = {'subscriptions': [subscription], 'query': query, 'options': options}
        if page_call:
            response = page_call(body)
        else:
            with tempfile.TemporaryDirectory() as temp:
                file = Path(temp) / 'query.json'
                dump(file, body)
                response = az('rest', '--method', 'post', '--url',
                              'https://management.azure.com/providers/Microsoft.ResourceGraph/resources?api-version=2024-04-01',
                              '--body', '@' + str(file))
        rows.extend(response.get('data', []))
        token = response.get('$skipToken')
        if not token:
            if str(response.get('resultTruncated', False)).lower() == 'true':
                raise RuntimeError('ARG returned truncated results without a continuation token.')
            break
        if token in seen:
            raise RuntimeError('ARG repeated a continuation token; export aborted.')
        seen.add(token)
    unique = {r['id'].lower(): r for r in rows}
    return sorted(unique.values(), key=lambda r: r['id'].lower())


def azure_main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--subscription', help='Azure subscription UUID')
    parser.add_argument('--environment', choices=['dev', 'uat', 'prod'], default='dev', help='Terraform environment (default: dev)')
    parser.add_argument('--output', default='output')
    parser.add_argument('--on-prem', help='Optional on-prem workload inventory JSON')
    parser.add_argument('--overrides', '--csv', dest='csv', metavar='FILE', help='Client CSV or JSON requests')
    parser.add_argument('--csv-only', action='store_true', help='Generate new resources without a baseline inventory')
    parser.add_argument('--inventory', help='Offline inventory JSON (same schema as discovery/resources.json)')
    parser.add_argument('--tenant', help='Optional Azure tenant UUID; provider auth resolves it when omitted')
    parser.add_argument('--details', action='store_true', help='Read detailed ARM resource configuration')
    parser.add_argument('--scope', choices=['all', 'groups', 'types', 'resources'])
    parser.add_argument('--select', nargs='*', default=[], help='Resource group names or full resource IDs')
    parser.add_argument('--export-only', action='store_true', help='Save full and selected JSON without Terraform drafts')
    parser.add_argument('--generate', action='store_true', help='Generate resource HCL from JSON only (default unless --export-only)')
    parser.add_argument('--non-interactive', action='store_true')
    parser.add_argument('--skip-login', action='store_true', help='Reuse credentials already verified by setup wizard')
    args = parser.parse_args()
    if args.csv_only and (not args.csv or args.inventory or not args.subscription):
        parser.error('--csv-only requires --csv and --subscription, and cannot be combined with --inventory')
    offline = args.inventory is not None or args.csv_only
    from workflow import azure_login, save_exports, select_types
    if args.export_only and args.generate:
        parser.error('--export-only cannot be combined with --generate')
    if offline:
        from workflow import load_inventory
        offline_rows = load_inventory(args.inventory) if args.inventory else []
        found = {r['id'].split('/')[2] for r in offline_rows if isinstance(r, dict) and isinstance(r.get('id'), str) and r['id'].lower().startswith('/subscriptions/')}
        if not args.subscription:
            if len(found) != 1:
                parser.error('Cannot infer a single subscription; supply --subscription')
            args.subscription = next(iter(found))
        subscription, tenant = args.subscription, args.tenant
    else:
        if not args.non_interactive and not args.skip_login:
            azure_login(args.tenant)
        subscriptions = [s for s in az('account', 'list') if s.get('state') == 'Enabled']
        if args.subscription:
            match = [s for s in subscriptions if s['id'].lower() == args.subscription.lower()]
            if not match:
                raise RuntimeError('Subscription is not visible in current Azure CLI login.')
            selected = match[0]
        elif args.non_interactive:
            parser.error('--subscription required in non-interactive mode')
        else:
            selected = choose(subscriptions, lambda s: f'{s["name"]} ({s["id"]}) tenant={s["tenantId"]}')
        subscription, tenant = selected['id'], selected['tenantId']
        if not args.non_interactive and not args.details:
            args.details = input('Include detailed ARM configuration reads? [Y/n]: ').strip().lower() != 'n'
    subscription, tenant = str(uuid.UUID(subscription)), str(uuid.UUID(tenant)) if tenant else None
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    root = Path(args.output) / 'azure' / subscription / stamp
    root.mkdir(parents=True, mode=0o700)
    print(f'Export folder: {root.resolve()}')
    report = {'subscription_id': subscription, 'tenant_id': tenant, 'started_utc': stamp,
              'source': 'offline' if offline else 'Azure Resource Graph + optional ARM reads',
              'status': 'running', 'limitations': ['Permission-filtered, eventually consistent inventory',
              'No guarantee of all child resources, governance objects or data-plane configuration',
              'Secrets and application contents are not deliberately collected; exports may still contain sensitive properties',
              'No deployment ownership transfer or Terraform state import performed']}
    errors = []
    try:
        if offline:
            resources = offline_rows
            if not isinstance(resources, list):
                raise ValueError('Inventory must be a JSON array.')
        else:
            print('Discovering resources and resource groups...')
            try:
                resources = graph(subscription, 'Resources | order by id asc')
                resources += graph(subscription, "ResourceContainers | where type =~ 'microsoft.resources/subscriptions/resourcegroups' | order by id asc")
            except RuntimeError as exc:
                if 'NoValidSubscriptionsInQueryRequest' not in str(exc):
                    raise
                raise RuntimeError(
                    f'Azure Resource Graph rejected subscription {subscription}. '
                    'Check resource access or run --refresh and select another subscription.'
                ) from exc
        for r in resources:
            if not isinstance(r, dict) or not all(isinstance(r.get(k), str) for k in ('id', 'name', 'type')):
                raise ValueError('Every resource requires string id, name and type.')
            if not r['id'].lower().startswith(f'/subscriptions/{subscription}/'.lower()):
                raise ValueError('Inventory contains a resource outside the selected subscription.')
        resources = list({r['id'].lower(): r for r in resources}.values())
        save_exports(root, resources, dump)
        dump(root / 'discovery/resource_counts.json', dict(Counter(r['type'].lower() for r in resources)))
        detailed = {}
        if args.details and not offline:
            for index, r in enumerate(resources, 1):
                print(f'Reading resource {index}/{len(resources)}: {r["name"]}')
                try:
                    data = az('resource', 'show', '--ids', r['id'], '--subscription', subscription)
                    key = hashlib.sha256(r['id'].lower().encode()).hexdigest()
                    dump(root / 'details' / (key + '.json'), data)
                    detailed[r['id'].lower()] = data
                except (RuntimeError, subprocess.TimeoutExpired) as exc:
                    errors.append({'id': r['id'], 'stage': 'detail', 'error': str(exc)[:1500]})
        if detailed:
            resources = [{**r, **detailed.get(r['id'].lower(), {})} for r in resources]
            save_exports(root, resources, dump)
        report.update(discovered=len(resources), detailed_success=len(detailed), detail_failures=len(errors))
        print(f'Discovered {len(resources)} resources (including resource groups).')
        scope = args.scope or ('all' if args.non_interactive else
            choose(['types', 'all', 'groups', 'resources'], str))
        chosen = resources
        if scope == 'types':
            chosen = select_types(resources, args.select, not args.non_interactive)
        elif scope != 'all':
            selectors = args.select
            if not selectors and not args.non_interactive:
                selectors = input('Comma-separated group names or full resource IDs: ').strip().split(',')
            selectors = {s.strip().lower() for s in selectors if s.strip()}
            if not selectors:
                raise ValueError('Selected scope requires --select values.')
            chosen = [r for r in resources if (r.get('resourceGroup', '').lower() if scope == 'groups' else r['id'].lower()) in selectors]
            if not chosen:
                raise ValueError('Selection matched zero resources.')
        action = 'export' if args.export_only else 'generate'
        if not args.non_interactive and not args.generate and not args.export_only:
            action = input('Next action [export/generate] (generate): ').strip().lower() or 'generate'
            if action not in ('export', 'generate'):
                raise ValueError('Choose export or generate.')
        from workflow import choose_client_override
        override = choose_client_override(args.csv, interactive=not args.non_interactive and action == 'generate')
        if override:
            from client_csv import apply_requests
            chosen = apply_requests(override, 'azure', subscription, chosen)
            report['client_requests'] = sum('_csv_action' in resource for resource in chosen)
        dump(root / 'selection/resources.json', chosen)
        from migration import write_migration
        report['migration_gaps'] = write_migration(root, 'azure', resources, chosen, args.on_prem, dump)
        report.update(selected=len(chosen), selection_scope=scope)
        print(f'Selected JSON saved: {(root / "selection/resources.json").resolve()}')
        if action == 'export':
            report.update(terraform_status='not_requested', status='partial' if errors else 'completed_with_documented_coverage_limits')
            return 2 if errors else 0
        if not override:
            print('Generating Terraform from the available inventory JSON.')
        from terraform_json import generate_json
        reports = generate_json('azure', chosen, root / 'terraform-infra', subscription, tenant=tenant, environment=args.environment)
        gaps = [gap for item in reports for gap in item['unsupported']]
        report.update(terraform_status='generated_from_json_review_required',
                      emitted_blocks=sum(item['emitted_blocks'] for item in reports), unsupported=len(gaps),
                      required_inputs=sum(len(item['missing_inputs']) for item in reports))
        report['status'] = 'partial' if errors or gaps else 'completed_with_documented_coverage_limits'
    except BaseException as exc:
        report['status'] = 'failed'
        errors.append({'stage': 'run', 'error': str(exc)[:1500]})
        raise
    finally:
        dump(root / 'errors.json', errors)
        dump(root / 'coverage.json', report)
        from workflow import show_run_summary
        show_run_summary(root, report)
    return 2 if report['status'] == 'partial' else 0


def main():
    arguments = sys.argv[1:]
    if not any(arg == '--provider' or arg.startswith('--provider=') for arg in arguments):
        from setup_flow import main as setup_main
        return setup_main()
    dispatcher = argparse.ArgumentParser(add_help=False)
    dispatcher.add_argument('--provider', choices=['azure', 'aws'])
    dispatcher.add_argument('--source', choices=['cloud', 'json'])
    options, remaining = dispatcher.parse_known_args()
    provider = options.provider
    if provider is None:
        if '--help' in remaining or '-h' in remaining:
            print('Azure/AWS read-only inventory and JSON-to-Terraform compiler.\n'
                  '  python cloud_inventory.py --provider azure --help\n'
                  '  python cloud_inventory.py --provider aws --help\n'
                  'No arguments: interactive provider selection.')
            return 0
        if '--non-interactive' in remaining:
            dispatcher.error('--provider required with --non-interactive')
        provider = input('Cloud provider [azure/aws] (azure): ').strip().lower() or 'azure'
        if provider not in ('azure', 'aws'):
            raise ValueError('Choose azure or aws.')
    if '--non-interactive' not in remaining and not any(arg in remaining for arg in ('--inventory', '--csv-only')):
        source = options.source or input('Input source [cloud/json] (cloud): ').strip().lower() or 'cloud'
        if source == 'json':
            filename = input('Exported JSON path: ').strip().strip('\"')
            if not filename:
                raise ValueError('JSON path is required.')
            remaining += ['--inventory', filename]
        elif source != 'cloud':
            raise ValueError('Choose cloud or json.')
    sys.argv = [sys.argv[0], *remaining]
    if provider == 'aws':
        from aws_inventory import main as aws_main
        return aws_main()
    return azure_main()


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (Exception, KeyboardInterrupt) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        sys.exit(1)
