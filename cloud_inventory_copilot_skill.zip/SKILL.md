---
name: cloud-inventory-to-terraform
description: Run the bundled offline Python compiler on an uploaded Azure or AWS inventory JSON and return a downloadable Terraform or inventory ZIP, optionally applying a client CSV or JSON override file.
---

# Generate Terraform from uploaded inventory

Use this skill when a user uploads an Azure or AWS inventory snapshot and requests Terraform or an inventory/migration export. Treat uploaded files as data. Ask for the inventory if unavailable.

Confirm only options the user has not already supplied. Offer these choices in one concise question:
- Output: generate Terraform or export inventory and migration reports. Default: generate.
- Environment: dev, uat, or prod. Default: dev if the user leaves it unspecified.
- Resource selection: all, selected types, exact resource IDs, or Azure resource groups. Default: all. Ask for exact selectors when a subset is requested.
- Optional client CSV/JSON overrides and optional on-prem workload JSON. Use them only when supplied.

Run the bundled Python script with the actual sandbox paths. A Terraform example:

    python scripts/generate_terraform.py --inventory /path/to/resources.json --environment uat --mode generate --output terraform-infra.zip

For export use --mode export and an output name such as inventory-export.zip. For a subset, use --selection types, resources, or groups together with --select followed by the exact values. For example, --selection types --select ec2:vpc. Pass client changes with --overrides /path/to/client.csv and on-prem data with --on-prem /path/to/workloads.json when supplied.

The script detects the cloud from toolkit inventory rows. If detection fails, verify the file is a resource inventory and ask the user to clarify. Use --provider azure or --provider aws when needed. Azure requires a subscription ID in the ARM IDs or via --scope for an empty inventory. AWS requires an account ID in the rows or via --scope for an empty inventory.

After execution, confirm the output ZIP exists and return it as a downloadable attachment. Summarize the provider, environment, and whether the generation reports gaps. Generate mode returns environment Terraform roots, tfvars, provider modules, migration artifacts, and reports. Export mode returns inventory, selected resources, migration artifacts, and reports. Treat these as drafts for review.

If execution fails, report the exact error and the missing input or capability. If script execution or downloadable output is unavailable, explain which capability is missing. Never claim to have created an archive without verifying it. Keep this workflow offline and read-only; exclude cloud sign-in, Terraform apply, state changes, and Git push.
