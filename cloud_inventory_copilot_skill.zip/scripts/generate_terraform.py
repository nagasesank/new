"""Compile an uploaded toolkit inventory and return an inventory or Terraform ZIP."""
import argparse
from pathlib import Path
import sys
import tempfile
import zipfile

import cloud_inventory
from workflow import load_inventory


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--environment', choices=('dev', 'uat', 'prod'), required=True)
    parser.add_argument('--provider', choices=('azure', 'aws'))
    parser.add_argument('--scope', help='Azure subscription ID or AWS account ID')
    parser.add_argument('--mode', choices=('generate', 'export'), default='generate')
    parser.add_argument('--selection', choices=('all', 'types', 'resources', 'groups'), default='all')
    parser.add_argument('--select', nargs='+', help='Resource types, IDs or Azure resource group names')
    parser.add_argument('--overrides', type=Path)
    parser.add_argument('--on-prem', type=Path, help='Optional source workload inventory JSON')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.suffix.lower() != '.zip' or args.output.exists():
        parser.error('--output must be a new .zip file')
    rows = load_inventory(args.inventory)
    if not all(isinstance(row, dict) for row in rows):
        parser.error('Inventory rows must be JSON objects')
    detected = set()
    for row in rows:
        if row.get('provider') == 'aws' or row.get('account_id'):
            detected.add('aws')
        elif str(row.get('id', '')).lower().startswith('/subscriptions/'):
            detected.add('azure')
        else:
            parser.error('Use discovery/resources.json from the toolkit. An inventory row has no recognized cloud identity.')
    if len(detected) > 1:
        parser.error('Supply one AWS account or Azure subscription inventory per run')
    provider = args.provider or next(iter(detected), None)
    if provider is None or detected - {provider}:
        parser.error('Specify a matching --provider')
    if (args.selection == 'all') == bool(args.select):
        parser.error('--select is required for types/resources/groups and omitted for all')
    if args.selection == 'groups' and provider != 'azure':
        parser.error('Resource group selection is available for Azure only')
    with tempfile.TemporaryDirectory() as directory:
        original_argv = sys.argv
        try:
            sys.argv = [str(Path(cloud_inventory.__file__)), '--provider', provider,
                        '--inventory', str(args.inventory.resolve()), '--environment', args.environment,
                        '--output', directory, '--scope', args.selection, '--non-interactive',
                        '--generate' if args.mode == 'generate' else '--export-only']
            if args.select:
                sys.argv += ['--select', *args.select]
            if args.on_prem:
                sys.argv += ['--on-prem', str(args.on_prem.resolve())]
            if args.scope:
                sys.argv += ['--subscription' if provider == 'azure' else '--account-id', args.scope]
            if args.overrides:
                sys.argv += ['--overrides', str(args.overrides.resolve())]
            status = cloud_inventory.main()
        finally:
            sys.argv = original_argv
        reports = list(Path(directory).glob('*/*/*/coverage.json'))
        if status not in (0, 2) or len(reports) != 1:
            raise RuntimeError('The toolkit did not produce a complete run folder')
        run = reports[0].parent
        repository = run / 'terraform-infra'
        if args.mode == 'generate' and not list((repository / 'environments').rglob('main.tf')):
            raise RuntimeError('No Terraform root was generated. Check the selected inventory and generator coverage.')
        with zipfile.ZipFile(args.output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
            folders = ('terraform-infra', 'migration') if args.mode == 'generate' else ('discovery', 'selection', 'migration')
            for folder in folders:
                for path in sorted((run / folder).rglob('*')):
                    archive.write(path, path.relative_to(run))
            for name in ('coverage.json', 'errors.json'):
                archive.write(run / name, Path('reports') / name)
        print(f'Created {args.output.resolve()} | {provider} | {args.environment} | {args.mode} | '
              f'{"partial: review reports" if status == 2 else "generated: review reports"}')


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError) as exc:
        sys.exit(f'ERROR: {exc}')
