"""Deterministic snapshot-to-HCL compiler. No SDK, network or subprocess calls."""
from collections import defaultdict
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
from urllib.parse import unquote


@dataclass(frozen=True)
class Expr:
    value: str


@dataclass(frozen=True)
class EncodedJSON:
    data: dict


@dataclass
class Block:
    name: str
    attrs: dict
    children: list = None


def quoted(value):
    # Prevent literal exported strings becoming Terraform template expressions.
    return json.dumps(str(value), ensure_ascii=False).replace('${', '$${').replace('%{', '%%{')


def value(v):
    if isinstance(v, Expr):
        return v.value
    if isinstance(v, str):
        return quoted(v)
    if isinstance(v, dict):
        return '{' + ', '.join(quoted(k) + ' = ' + value(x) for k, x in v.items()) + '}'
    if isinstance(v, list):
        return '[' + ', '.join(value(x) for x in v) + ']'
    return json.dumps(v, allow_nan=False)


def block(name, attrs, children=None, indent=0):
    pad = '  ' * indent
    lines = [pad + name + ' {']
    lines += [pad + '  ' + k + ' = ' + value(v) for k, v in attrs.items() if v is not None]
    for child in children or []:
        lines.append(block(child.name, child.attrs, child.children, indent + 1))
    lines.append(pad + '}')
    return '\n'.join(lines)


AZURE_TYPES = {
 'microsoft.resources/subscriptions/resourcegroups': ('azurerm_resource_group', 'main.tf'),
 'microsoft.network/virtualnetworks': ('azurerm_virtual_network', 'networking.tf'),
 'microsoft.network/virtualnetworks/subnets': ('azurerm_subnet', 'networking.tf'),
 'microsoft.network/networksecuritygroups': ('azurerm_network_security_group', 'networking.tf'),
 'microsoft.network/publicipaddresses': ('azurerm_public_ip', 'networking.tf'),
 'microsoft.network/networkinterfaces': ('azurerm_network_interface', 'networking.tf'),
 'microsoft.storage/storageaccounts': ('azurerm_storage_account', 'storage.tf'),
 'microsoft.managedidentity/userassignedidentities': ('azurerm_user_assigned_identity', 'iam.tf'),
 'microsoft.compute/disks': ('azurerm_managed_disk', 'compute.tf'),
 'microsoft.compute/virtualmachines': ('azurerm_linux_virtual_machine', 'compute.tf'),
}
AWS_TYPES = {
 'ec2:vpc': ('aws_vpc', 'networking.tf'),
 'ec2:subnet': ('aws_subnet', 'networking.tf'),
 'ec2:security-group': ('aws_security_group', 'networking.tf'),
 'ec2:internet-gateway': ('aws_internet_gateway', 'networking.tf'),
 'ec2:route-table': ('aws_route_table', 'networking.tf'),
 'ec2:elastic-ip': ('aws_eip', 'networking.tf'),
 'ec2:nat-gateway': ('aws_nat_gateway', 'networking.tf'),
 'ec2:volume': ('aws_ebs_volume', 'storage.tf'),
 'ec2:instance': ('aws_instance', 'compute.tf'),
 's3:bucket': ('aws_s3_bucket', 'storage.tf'),
 'iam:role': ('aws_iam_role', 'iam.tf'),
 'iam:policy': ('aws_iam_policy', 'iam.tf'),
 'logs:log-group': ('aws_cloudwatch_log_group', 'monitoring.tf'),
 'ecr:repository': ('aws_ecr_repository', 'storage.tf'),
}


def normalize_azure(rows):
    """Expand embedded subnets once; standalone exports win on duplicate IDs."""
    result = {r['id'].lower(): dict(r) for r in rows}
    for r in rows:
        if r['type'].lower() == 'microsoft.network/virtualnetworks':
            for subnet in r.get('properties', {}).get('subnets', []):
                rid = subnet.get('id') or r['id'] + '/subnets/' + subnet['name']
                row = {**subnet, 'id': rid, 'name': subnet.get('name', rid.rsplit('/', 1)[-1]),
                       'type': 'Microsoft.Network/virtualNetworks/subnets',
                       'resourceGroup': r.get('resourceGroup'), 'location': r.get('location')}
                if r.get('_csv_action') == 'create':
                    row['_csv_action'] = 'create'
                result.setdefault(rid.lower(), row)
    return sorted(result.values(), key=lambda r: r['id'].lower())


class Compiler:
    def __init__(self, provider, rows, folder, account, tenant=None, region=None, profile=None, *, repository, module_scope=None):
        self.provider, self.rows, self.folder = provider, rows, Path(folder)
        self.account, self.tenant, self.region, self.profile = account, tenant, region, profile
        self.repository = Path(repository)
        self.module_scope = module_scope
        self.variables, self.files, self.imports, self.mapping = {}, defaultdict(list), [], []
        self.resource_blocks = {}
        self.tfvars = {}
        self.missing, self.external, self.unsupported, self.warnings = [], [], [], []
        self.addresses = {}
        self.primary = {}
        self.specs = AZURE_TYPES if provider == 'azure' else AWS_TYPES
        for r in rows:
            kind = r['type'].lower()
            spec = self.specs.get(kind)
            if provider == 'azure' and kind == 'microsoft.compute/virtualmachines':
                ostype = r.get('properties', {}).get('storageProfile', {}).get('osDisk', {}).get('osType')
                if ostype == 'Windows':
                    spec = ('azurerm_windows_virtual_machine', 'compute.tf')
                elif ostype != 'Linux':
                    spec = None
                if r.get('properties', {}).get('storageProfile', {}).get('osDisk', {}).get('createOption') == 'Attach':
                    spec = None
            if spec:
                target = spec[0] + '.' + self.label(r['id'], r['name'])
                self.addresses[self.key(r['id'])] = target
                self.primary[self.key(r['id'])] = spec
            else:
                self.unsupported.append({'id': r['id'], 'type': r['type'], 'reason': 'No JSON emitter for type/OS/disk mode; inventory retained'})

    def key(self, rid):
        return rid.lower() if self.provider == 'azure' else rid

    def label(self, identity, name):
        safe = re.sub(r'[^a-z0-9_]', '_', name.lower())[:48]
        return 'r_' + safe + '_' + hashlib.sha256(identity.encode()).hexdigest()[:10]

    def variable(self, r, field, kind='string', sensitive=False, reason='Missing in JSON'):
        name = self.label(r['id'], r['name']) + '_' + re.sub(r'[^a-z0-9_]', '_', field.lower())
        self.variables[name] = {'type': kind, 'sensitive': sensitive,
                                'description': f'{field} for {r["id"]}. {reason}'}
        entry = {'resource_id': r['id'], 'field': field, 'variable': name, 'reason': reason}
        if entry not in self.missing:
            self.missing.append(entry)
        return Expr('var.' + name)

    def need(self, r, field, val, kind='string', sensitive=False):
        return self.variable(r, field, kind, sensitive) if val is None or val == '' or val == [] or val == '[REDACTED]' else val

    def ref(self, r, field, rid, attribute='id'):
        if not rid:
            return self.variable(r, field)
        target = self.addresses.get(self.key(rid))
        if target:
            return Expr(target + '.' + attribute)
        self.external.append({'resource_id': r['id'], 'field': field, 'external_id': rid})
        return self.variable(r, field, reason='Dependency outside emitted scope; exported ID retained only in report')

    def add(self, r, tf_type, attrs, children=None, suffix='', import_id=None, filename=None):
        label = self.label(r['id'] + suffix, r['name'] + suffix)
        address = tf_type + '.' + label
        file = filename or self.primary[self.key(r['id'])][1]
        self.resource_blocks[address] = (Path(file).stem if file != 'main.tf' else 'foundation',
                                         Block('resource ' + quoted(tf_type) + ' ' + quoted(label), attrs, children))
        if r.get('_csv_action') != 'create':
            self.imports.append(Block('import', {'to': Expr(address), 'id': r['id'] if import_id is None else import_id}))
        self.mapping.append({'id': r['id'], 'address': address, 'file': file})
        return address

    def azure(self, r):
        kind = r['type'].lower()
        spec = self.primary.get(self.key(r['id']))
        if not spec:
            return
        tf_type = spec[0]
        p = r.get('properties') or {}
        name = r['name'].rsplit('/', 1)[-1]
        rg = r.get('resourceGroup') or (r['id'].split('/')[4] if '/resourcegroups/' in r['id'].lower() else None)
        rgid = '/subscriptions/' + self.account + '/resourceGroups/' + str(rg)
        attrs = {'name': name}
        if tf_type != 'azurerm_subnet':
            attrs['location'] = self.need(r, 'location', r.get('location'))
        if tf_type != 'azurerm_resource_group':
            attrs['resource_group_name'] = self.ref(r, 'resource_group_name', rgid, 'name') if rg else self.variable(r, 'resource_group_name')
        if tf_type not in ('azurerm_subnet',) and 'tags' in r:
            attrs['tags'] = r['tags']
        children = []
        if tf_type == 'azurerm_virtual_network':
            attrs['address_space'] = self.need(r, 'address_space', p.get('addressSpace', {}).get('addressPrefixes'), 'list(string)')
            if 'dnsServers' in p.get('dhcpOptions', {}):
                attrs['dns_servers'] = p['dhcpOptions']['dnsServers']
        elif tf_type == 'azurerm_subnet':
            parent_id = r['id'].rsplit('/subnets/', 1)[0]
            attrs['virtual_network_name'] = self.ref(r, 'virtual_network_name', parent_id, 'name')
            prefixes = p.get('addressPrefixes') or ([p['addressPrefix']] if p.get('addressPrefix') else None)
            attrs['address_prefixes'] = self.need(r, 'address_prefixes', prefixes, 'list(string)')
            if 'serviceEndpoints' in p:
                attrs['service_endpoints'] = [x['service'] for x in p['serviceEndpoints']]
        elif tf_type == 'azurerm_network_security_group':
            if 'securityRules' not in p:
                self.warnings.append({'id': r['id'], 'message': 'securityRules missing; rule completeness unknown'})
            for rule in p.get('securityRules', []):
                rp = rule.get('properties', {})
                a = {'name': rule['name']}
                fields = {'priority':'priority','direction':'direction','access':'access','protocol':'protocol',
                          'sourcePortRange':'source_port_range','sourcePortRanges':'source_port_ranges',
                          'destinationPortRange':'destination_port_range','destinationPortRanges':'destination_port_ranges',
                          'sourceAddressPrefix':'source_address_prefix','sourceAddressPrefixes':'source_address_prefixes',
                          'destinationAddressPrefix':'destination_address_prefix','destinationAddressPrefixes':'destination_address_prefixes',
                          'description':'description'}
                for source, dest in fields.items():
                    if source in rp and rp[source] not in (None, '', []):
                        a[dest] = rp[source]
                for required in ('priority','direction','access','protocol'):
                    a[required] = self.need(r, rule['name']+'_'+required, a.get(required), 'number' if required == 'priority' else 'string')
                for single, plural in [('source_port_range','source_port_ranges'),('destination_port_range','destination_port_ranges'),
                                       ('source_address_prefix','source_address_prefixes'),('destination_address_prefix','destination_address_prefixes')]:
                    if single not in a and plural not in a:
                        a[single] = self.variable(r, rule['name']+'_'+single)
                children.append(Block('security_rule', a))
        elif tf_type == 'azurerm_public_ip':
            attrs['allocation_method'] = self.need(r, 'allocation_method', p.get('publicIPAllocationMethod'))
            if r.get('sku', {}).get('name'):
                attrs['sku'] = r['sku']['name']
            if 'zones' in r:
                attrs['zones'] = r['zones']
            for src, dst in [('publicIPAddressVersion','ip_version'),('idleTimeoutInMinutes','idle_timeout_in_minutes')]:
                if src in p:
                    attrs[dst] = p[src]
        elif tf_type == 'azurerm_network_interface':
            for src, dst in [('enableAcceleratedNetworking','accelerated_networking_enabled'),('enableIPForwarding','ip_forwarding_enabled')]:
                if src in p:
                    attrs[dst] = p[src]
            configs = p.get('ipConfigurations', [])
            if not configs:
                children.append(Block('ip_configuration', {
                    'name': self.variable(r,'ip_configuration_name'),
                    'subnet_id': self.variable(r,'subnet_id'),
                    'private_ip_address_allocation': self.variable(r,'private_ip_address_allocation')}))
            for ip in configs:
                q = ip.get('properties', {})
                a = {'name': ip['name'], 'subnet_id': self.ref(r, 'subnet_id_' + ip['name'], q.get('subnet', {}).get('id')),
                     'private_ip_address_allocation': self.need(r, 'private_ip_allocation_' + ip['name'], q.get('privateIPAllocationMethod'))}
                if q.get('privateIPAllocationMethod') == 'Static':
                    a['private_ip_address'] = self.need(r, 'private_ip_address', q.get('privateIPAddress'))
                if q.get('publicIPAddress', {}).get('id'):
                    a['public_ip_address_id'] = self.ref(r, 'public_ip_address_id', q['publicIPAddress']['id'])
                if 'primary' in q:
                    a['primary'] = q['primary']
                children.append(Block('ip_configuration', a))
        elif tf_type == 'azurerm_storage_account':
            sku = r.get('sku', {}).get('name', '').split('_', 1)
            attrs['account_tier'] = self.need(r, 'account_tier', sku[0] if sku and sku[0] else None)
            attrs['account_replication_type'] = self.need(r, 'account_replication_type', sku[1] if len(sku) == 2 else None)
            attrs['account_kind'] = self.need(r, 'account_kind', r.get('kind'))
            for src,dst in [('minimumTlsVersion','min_tls_version'),('supportsHttpsTrafficOnly','https_traffic_only_enabled'),
                            ('allowBlobPublicAccess','allow_nested_items_to_be_public'),('allowSharedKeyAccess','shared_access_key_enabled'),
                            ('accessTier','access_tier')]:
                if src in p:
                    attrs[dst] = p[src]
            if p.get('publicNetworkAccess') in ('Enabled','Disabled'):
                attrs['public_network_access_enabled'] = p['publicNetworkAccess'] == 'Enabled'
            if p.get('networkAcls'):
                self.warnings.append({'id':r['id'],'message':'Storage network ACLs require manual mapping; not emitted'})
        elif tf_type == 'azurerm_managed_disk':
            attrs['storage_account_type'] = self.need(r, 'storage_account_type', r.get('sku', {}).get('name'))
            create = p.get('creationData', {}).get('createOption')
            attrs['create_option'] = self.need(r, 'create_option', create)
            if create not in (None, 'Empty'):
                self.warnings.append({'id':r['id'],'message':'Nonempty disk creation data may require source/image/import inputs'})
            if 'diskSizeGB' in p:
                attrs['disk_size_gb'] = p['diskSizeGB']
        elif tf_type in ('azurerm_linux_virtual_machine','azurerm_windows_virtual_machine'):
            osprofile = p.get('osProfile', {})
            attrs['size'] = self.need(r, 'size', p.get('hardwareProfile', {}).get('vmSize'))
            attrs['admin_username'] = self.need(r, 'admin_username', osprofile.get('adminUsername'))
            ids = p.get('networkProfile', {}).get('networkInterfaces')
            attrs['network_interface_ids'] = ([self.ref(r, 'network_interface_id_' + str(i), n.get('id')) for i,n in enumerate(ids)]
                                              if ids else self.variable(r, 'network_interface_ids', 'list(string)'))
            disk = p.get('storageProfile', {}).get('osDisk', {})
            children.append(Block('os_disk', {'caching': self.need(r, 'os_disk_caching', disk.get('caching')),
                'storage_account_type': self.need(r, 'os_disk_storage_account_type', disk.get('managedDisk', {}).get('storageAccountType'))}))
            image = p.get('storageProfile', {}).get('imageReference', {})
            if image.get('id'):
                attrs['source_image_id'] = image['id']
            elif all(image.get(k) for k in ('publisher','offer','sku','version')):
                children.append(Block('source_image_reference', {k:image[k] for k in ('publisher','offer','sku','version')}))
            else:
                attrs['source_image_id'] = self.variable(r, 'source_image_id')
            if tf_type == 'azurerm_windows_virtual_machine':
                attrs['admin_password'] = self.variable(r, 'admin_password', sensitive=True, reason='Password is not recoverable from inventory')
            else:
                ssh = osprofile.get('linuxConfiguration', {}).get('ssh', {}).get('publicKeys', [])
                if osprofile.get('linuxConfiguration', {}).get('disablePasswordAuthentication') is False:
                    attrs['disable_password_authentication'] = False
                    attrs['admin_password'] = self.variable(r, 'admin_password', sensitive=True)
                else:
                    attrs['disable_password_authentication'] = True
                    public_key = ssh[0].get('keyData') if ssh else None
                    children.append(Block('admin_ssh_key', {'username': attrs['admin_username'],
                        'public_key': self.need(r, 'ssh_public_key', public_key)}))
            self.warnings.append({'id':r['id'],'message':'VM extensions, data disks and identity settings need separate review'})
        self.add(r, tf_type, attrs, children)
        nsg = p.get('networkSecurityGroup', {}).get('id')
        if nsg and tf_type in ('azurerm_subnet', 'azurerm_network_interface'):
            assoc = 'azurerm_subnet_network_security_group_association' if tf_type == 'azurerm_subnet' else 'azurerm_network_interface_security_group_association'
            field = 'subnet_id' if tf_type == 'azurerm_subnet' else 'network_interface_id'
            self.add(r, assoc, {field: Expr(self.addresses[self.key(r['id'])] + '.id'),
                'network_security_group_id': self.ref(r,'network_security_group_id',nsg)}, suffix='_nsg', filename='networking.tf')

    def aws(self, r):
        spec = self.primary.get(self.key(r['id']))
        if not spec:
            return
        typ = spec[0]
        p = r.get('properties') or {}
        a, children = {}, []
        tags = p.get('Tags', p.get('tags'))
        if tags is not None:
            a['tags'] = ({t['Key']:t['Value'] for t in tags} if isinstance(tags,list) else tags)
        if typ == 'aws_vpc':
            a['cidr_block'] = self.need(r, 'cidr_block', p.get('CidrBlock'))
            for key,dest in [('EnableDnsSupport','enable_dns_support'),('EnableDnsHostnames','enable_dns_hostnames'),('InstanceTenancy','instance_tenancy')]:
                if key in p:
                    a[dest] = p[key]
        elif typ == 'aws_subnet':
            a.update(vpc_id=self.ref(r,'vpc_id',p.get('VpcId')), cidr_block=self.need(r,'cidr_block',p.get('CidrBlock')))
            for key,dest in [('AvailabilityZone','availability_zone'),('MapPublicIpOnLaunch','map_public_ip_on_launch'),('Ipv6CidrBlock','ipv6_cidr_block')]:
                if key in p:
                    a[dest] = p[key]
        elif typ == 'aws_security_group':
            a.update(name=self.need(r,'name',p.get('GroupName')), description=self.need(r,'description',p.get('Description')),
                     vpc_id=self.ref(r,'vpc_id',p.get('VpcId')))
            for key,direction in [('IpPermissions','ingress'),('IpPermissionsEgress','egress')]:
                if key not in p:
                    self.warnings.append({'id':r['id'],'message':key+' missing; rule completeness unknown'})
                    continue
                if not p[key]:
                    a[direction] = []
                for rule in p[key]:
                    protocol = rule.get('IpProtocol')
                    q = {'protocol':self.need(r,'rule_protocol',protocol),
                         'from_port':rule.get('FromPort',0) if protocol == '-1' else self.need(r,'from_port',rule.get('FromPort'),'number'),
                         'to_port':rule.get('ToPort',0) if protocol == '-1' else self.need(r,'to_port',rule.get('ToPort'),'number')}
                    if rule.get('IpRanges'):
                        q['cidr_blocks'] = [x['CidrIp'] for x in rule['IpRanges']]
                    if rule.get('Ipv6Ranges'):
                        q['ipv6_cidr_blocks'] = [x['CidrIpv6'] for x in rule['Ipv6Ranges']]
                    if rule.get('PrefixListIds'):
                        q['prefix_list_ids'] = [x['PrefixListId'] for x in rule['PrefixListIds']]
                    groups = rule.get('UserIdGroupPairs', [])
                    if any(x.get('GroupId') == r['id'] for x in groups):
                        q['self'] = True
                    peers = [x for x in groups if x.get('GroupId') != r['id']]
                    if peers:
                        q['security_groups'] = [self.ref(r,'security_group_' + str(i),x.get('GroupId')) for i,x in enumerate(peers)]
                    children.append(Block(direction,q))
        elif typ == 'aws_internet_gateway':
            attachments = p.get('Attachments', [])
            if attachments:
                a['vpc_id'] = self.ref(r,'vpc_id',attachments[0].get('VpcId'))
        elif typ == 'aws_route_table':
            a['vpc_id'] = self.ref(r,'vpc_id',p.get('VpcId'))
            for route in p.get('Routes', []):
                if route.get('GatewayId') == 'local':
                    continue
                q = {}
                for src,dst in [('DestinationCidrBlock','cidr_block'),('DestinationIpv6CidrBlock','ipv6_cidr_block')]:
                    if src in route:
                        q[dst] = route[src]
                for src,dst in [('GatewayId','gateway_id'),('NatGatewayId','nat_gateway_id'),('NetworkInterfaceId','network_interface_id'),
                                ('TransitGatewayId','transit_gateway_id'),('VpcPeeringConnectionId','vpc_peering_connection_id')]:
                    if src in route:
                        q[dst] = self.ref(r,dst,route[src])
                if q:
                    children.append(Block('route',q))
            for assoc in p.get('Associations', []):
                if assoc.get('SubnetId') and assoc.get('RouteTableAssociationId'):
                    self.add(r,'aws_route_table_association',{'subnet_id':self.ref(r,'associated_subnet_id',assoc['SubnetId']),
                        'route_table_id':Expr(self.addresses[r['id']]+'.id')}, suffix='_' + assoc['RouteTableAssociationId'],
                        import_id=assoc['RouteTableAssociationId'],filename='networking.tf')
        elif typ == 'aws_eip':
            if 'Domain' in p:
                a['domain'] = p['Domain']
        elif typ == 'aws_nat_gateway':
            a['subnet_id'] = self.ref(r,'subnet_id',p.get('SubnetId'))
            if p.get('ConnectivityType'):
                a['connectivity_type'] = p['ConnectivityType']
            addresses = p.get('NatGatewayAddresses', [])
            if addresses and addresses[0].get('AllocationId'):
                a['allocation_id'] = self.ref(r,'allocation_id',addresses[0]['AllocationId'])
        elif typ == 'aws_ebs_volume':
            a['availability_zone'] = self.need(r,'availability_zone',p.get('AvailabilityZone'))
            for src,dst in [('Size','size'),('VolumeType','type'),('Encrypted','encrypted'),('Iops','iops'),('Throughput','throughput'),('SnapshotId','snapshot_id')]:
                if src in p and p[src] != '':
                    a[dst] = p[src]
        elif typ == 'aws_instance':
            a['ami'] = self.need(r,'ami',p.get('ImageId'))
            a['instance_type'] = self.need(r,'instance_type',p.get('InstanceType'))
            if p.get('SubnetId'):
                a['subnet_id'] = self.ref(r,'subnet_id',p['SubnetId'])
            if 'SecurityGroups' in p:
                a['vpc_security_group_ids'] = [self.ref(r,'security_group_' + str(i),x['GroupId']) for i,x in enumerate(p['SecurityGroups'])]
            for src,dst in [('KeyName','key_name'),('PrivateIpAddress','private_ip'),('EbsOptimized','ebs_optimized')]:
                if src in p:
                    a[dst] = p[src]
            if p.get('IamInstanceProfile'):
                a['iam_instance_profile'] = self.variable(r,'iam_instance_profile',reason='Instance-profile resource is not exported by this collector')
            self.warnings.append({'id':r['id'],'message':'User data, root volume settings, extra disks and instance-profile ownership require review'})
        elif typ == 'aws_s3_bucket':
            a['bucket'] = r['id']
            if 'TagSet' in p.get('get_bucket_tagging', {}):
                a['tags'] = {x['Key']:x['Value'] for x in p['get_bucket_tagging']['TagSet']}
            self.s3_settings(r,p)
        elif typ == 'aws_iam_role':
            a['name'] = p.get('RoleName', r['name'])
            doc = p.get('AssumeRolePolicyDocument')
            a['assume_role_policy'] = self.policy(r,'assume_role_policy',doc)
            for src,dst in [('Path','path'),('Description','description'),('MaxSessionDuration','max_session_duration')]:
                if src in p:
                    a[dst] = p[src]
            if p.get('list_attached_role_policies') or p.get('list_role_policies'):
                self.warnings.append({'id':r['id'],'message':'IAM attachments and inline policy contents are not emitted'})
        elif typ == 'aws_iam_policy':
            a['name'] = p.get('PolicyName',r['name'])
            a['policy'] = self.policy(r,'policy',p.get('default_version',{}).get('Document'))
            if 'Path' in p:
                a['path'] = p['Path']
        elif typ == 'aws_cloudwatch_log_group':
            a['name'] = p.get('logGroupName',r['name'])
            if 'retentionInDays' in p:
                a['retention_in_days'] = p['retentionInDays']
            if p.get('kmsKeyId'):
                a['kms_key_id'] = self.variable(r,'kms_key_id',reason='KMS resource not emitted')
        elif typ == 'aws_ecr_repository':
            a['name'] = p.get('repositoryName',r['name'])
            if 'imageTagMutability' in p:
                a['image_tag_mutability'] = p['imageTagMutability']
            if p.get('imageScanningConfiguration'):
                children.append(Block('image_scanning_configuration',{'scan_on_push':p['imageScanningConfiguration']['scanOnPush']}))
        self.add(r,typ,a,children)

    def policy(self,r,field,doc):
        if isinstance(doc,str):
            try:
                doc = json.loads(doc)
            except (ValueError,TypeError):
                try:
                    doc = json.loads(unquote(doc))
                except (ValueError,TypeError):
                    doc = None
        return EncodedJSON(doc) if isinstance(doc,dict) else self.variable(r,field,reason='Policy document missing/redacted')

    def s3_settings(self,r,p):
        bucket = Expr(self.addresses[r['id']] + '.id')
        version = p.get('get_bucket_versioning', {})
        if version.get('Status'):
            self.add(r,'aws_s3_bucket_versioning',{'bucket':bucket},[Block('versioning_configuration',{'status':version['Status']})],suffix='_versioning',import_id=r['id'],filename='storage.tf')
        public = p.get('get_public_access_block', {}).get('PublicAccessBlockConfiguration')
        if public:
            attrs = {'bucket':bucket}
            for src,dst in [('BlockPublicAcls','block_public_acls'),('IgnorePublicAcls','ignore_public_acls'),('BlockPublicPolicy','block_public_policy'),('RestrictPublicBuckets','restrict_public_buckets')]:
                if src in public:
                    attrs[dst] = public[src]
            self.add(r,'aws_s3_bucket_public_access_block',attrs,suffix='_public_access',import_id=r['id'],filename='storage.tf')
        policy = p.get('get_bucket_policy', {}).get('Policy')
        if policy:
            self.add(r,'aws_s3_bucket_policy',{'bucket':bucket,'policy':self.policy(r,'bucket_policy',policy)},suffix='_policy',import_id=r['id'],filename='storage.tf')
        encryption = p.get('get_bucket_encryption', {}).get('ServerSideEncryptionConfiguration',{}).get('Rules',[])
        if encryption:
            rules=[]
            for q in encryption:
                default=q.get('ApplyServerSideEncryptionByDefault',{})
                attrs={'sse_algorithm':self.need(r,'sse_algorithm',default.get('SSEAlgorithm'))}
                if default.get('KMSMasterKeyID'):
                    attrs['kms_master_key_id']=self.variable(r,'kms_master_key_id',reason='External KMS key; exported ID in inventory')
                ruleattrs={'bucket_key_enabled':q['BucketKeyEnabled']} if 'BucketKeyEnabled' in q else {}
                rules.append(Block('rule',ruleattrs,[Block('apply_server_side_encryption_by_default',attrs)]))
            self.add(r,'aws_s3_bucket_server_side_encryption_configuration',{'bucket':bucket},rules,suffix='_encryption',import_id=r['id'],filename='storage.tf')

    def module_folder(self, group):
        if group == 'foundation':
            return self.repository / 'cloud-infra' / 'foundation'
        service = 'identity' if self.provider == 'azure' and group == 'iam' else group
        folder = self.repository / 'modules' / self.provider / service
        return folder / self.module_scope if self.module_scope else folder

    def write_modules(self, provider_name):
        inputs = defaultdict(dict)
        outputs = defaultdict(dict)
        declarations = defaultdict(dict)
        resources = defaultdict(list)
        modules = {address: group for address, (group, _) in self.resource_blocks.items()}

        def exported(address, attribute):
            group = modules[address]
            token = hashlib.sha256(f'{address}.{attribute}'.encode()).hexdigest()[:16]
            name = 'resource_' + token
            outputs[group][name] = Expr(f'{address}.{attribute}')
            return Expr(f'module.{group}.{name}')

        def pass_input(group, name, definition, expression):
            inputs[group][name] = expression
            declarations[group][name] = definition
            return Expr('var.' + name)

        def parameterize(raw, group, address, path):
            if isinstance(raw, EncodedJSON):
                argument = parameterize(raw.data, group, address, path)
                return Expr('jsonencode(' + value(argument) + ')')
            if isinstance(raw, Expr):
                expression = raw.value
                if expression.startswith('var.'):
                    name = expression[4:]
                    return pass_input(group, name, self.variables[name], raw)
                target, _, attribute = expression.rpartition('.')
                if target in modules and modules[target] != group:
                    token = hashlib.sha256(expression.encode()).hexdigest()[:16]
                    return pass_input(group, 'dependency_' + token, {'type': 'any'},
                                      exported(target, attribute))
                return raw
            if isinstance(raw, list) and any(isinstance(item, (Expr, EncodedJSON)) for item in raw):
                return [parameterize(item, group, address, f'{path}_{i}') for i, item in enumerate(raw)]
            token = hashlib.sha256(f'{address}:{path}'.encode()).hexdigest()[:12]
            name = f'{address.split(".")[1]}_{path}_{token}'
            self.variables[name] = {'type': 'any', 'description': f'{address}.{path}'}
            self.tfvars[name] = raw
            return pass_input(group, name, self.variables[name], Expr('var.' + name))

        def convert(resource, group, address, prefix=''):
            attrs = {key: parameterize(raw, group, address, prefix + key)
                     for key, raw in resource.attrs.items() if raw is not None}
            children = [convert(child, group, address, f'{prefix}{child.name}_{index}_')
                        for index, child in enumerate(resource.children or [])]
            return Block(resource.name, attrs, children)

        for address, (group, resource) in self.resource_blocks.items():
            converted = convert(resource, group, address)
            resources[group].append(block(converted.name, converted.attrs, converted.children))

        resource_ids = {}
        for entry in self.mapping:
            address = entry['address']
            group = modules[address]
            entry['address'] = f'module.{group}.{address}'
            entry['file'] = (self.module_folder(group) / f'{group}.tf').relative_to(self.repository).as_posix()
            resource_ids[entry['address']] = exported(address, 'id')
        for item in self.imports:
            address = item.attrs['to'].value
            item.attrs['to'] = Expr(f'module.{modules[address]}.{address}')

        for group, blocks in resources.items():
            folder = self.module_folder(group)
            folder.mkdir(parents=True, exist_ok=True)
            required = block('terraform', {}, [Block('required_providers', {
                provider_name: {'source': 'hashicorp/' + provider_name}})])
            files = {
                group + '.tf': blocks,
                'variables.tf': [block('variable ' + quoted(name), {
                    'type': Expr(definition['type']), 'sensitive': definition.get('sensitive')})
                    for name, definition in declarations[group].items()],
                'outputs.tf': [block('output ' + quoted(name), {'value': expression})
                               for name, expression in outputs[group].items()],
                'versions.tf': [required],
            }
            for filename, content in files.items():
                (folder / filename).write_text('\n\n'.join(content) + '\n', encoding='utf-8')
            self.files['main.tf'].append(block('module ' + quoted(group), {
                'source': Path(os.path.relpath(folder, self.folder)).as_posix(), **inputs[group]}))
        self.files['outputs.tf'].append(block('output "resource_ids"', {'value': resource_ids}))
        return sorted(resources)

    def compile(self):
        self.folder.mkdir(parents=True,exist_ok=False)
        for r in self.rows:
            if self.key(r['id']) not in self.primary:
                continue
            try:
                (self.azure if self.provider == 'azure' else self.aws)(r)
            except (ValueError, KeyError, TypeError, IndexError) as exc:
                # Fail the generation rather than leave dangling forward references.
                raise ValueError(f'Malformed {r["id"]}: {exc}') from exc
        name = 'azurerm' if self.provider == 'azure' else 'aws'
        provider_version = '~> 4.0' if self.provider == 'azure' else '~> 6.0'
        self.files['versions.tf'].append(block('terraform',{'required_version':'>= 1.5.0, < 2.0.0'},
            [Block('required_providers',{name:{'source':'hashicorp/'+name,'version':provider_version}})]))
        if self.provider == 'azure':
            self.files['providers.tf'].append(block('provider "azurerm"',{'subscription_id':self.account,
                'tenant_id':self.tenant,'resource_provider_registrations':'none'},[Block('features',{})]))
        else:
            attrs={'region':self.region,'allowed_account_ids':[self.account]}
            if self.profile:
                attrs['profile']=self.profile
            self.files['providers.tf'].append(block('provider "aws"',attrs))
        self.files['main.tf'].insert(0,block('locals',{'inventory_provider':self.provider,'inventory_resource_count':len(self.rows)}))
        modules = self.write_modules(name)
        for var,definition in self.variables.items():
            attrs={'type':Expr(definition['type']),'description':definition['description']}
            if definition.get('sensitive'):
                attrs['sensitive']=True
            self.files['variables.tf'].append(block('variable '+quoted(var),attrs))
        self.files['imports.tf'] = [block(item.name, item.attrs) for item in self.imports]
        for file in ('main.tf','variables.tf','outputs.tf','imports.tf','versions.tf','providers.tf'):
            text='\n\n'.join(self.files[file]) or '# No resources of this category in the selected snapshot.'
            (self.folder/file).write_text('# Generated from inventory and optional client requests. Review generation_report.json before use.\n'+text+'\n',encoding='utf-8')
        (self.folder/'.gitignore').write_text('.terraform/\n*.tfstate*\n*.tfplan\n*.log\nterraform.tfvars\n*.auto.tfvars\n',encoding='utf-8')
        tfvars = self.folder / 'terraform.tfvars'
        tfvars.write_text(''.join(f'{name} = {value(raw)}\n' for name, raw in self.tfvars.items()), encoding='utf-8')
        tfvars.chmod(0o600)
        (self.folder/'terraform.tfvars.example').write_text('# Required inputs: replace null with real values; do not commit secrets.\n'+
            '\n'.join(name+' = null # '+spec['type'] for name,spec in self.variables.items() if name not in self.tfvars)+'\n',encoding='utf-8')
        report={'provider':self.provider,'source':'Inventory with client requests' if any(r.get('_csv_action') for r in self.rows) else 'JSON snapshot only; no live reads',
            'modules': modules, 'tfvars_values': len(self.tfvars),
            'input_resources':len(self.rows),'emitted_blocks':len(self.mapping),
            'unsupported':self.unsupported,'missing_inputs':self.missing,'external_dependencies':self.external,
            'warnings':self.warnings,'status':'review_required',
            'limits':['Explicit allowlisted field mappings, not a lossless cloud configuration export',
                'Snapshot configuration can be incomplete; provider defaults can differ',
                'Generated HCL is not a no-change plan guarantee; no state adoption performed',
                'No fmt/provider schema validation is claimed by the compiler']}
        for filename,data in [('generation_report.json',report),('resource_mapping.json',self.mapping),('generation_gaps.json',self.unsupported)]:
            (self.folder/filename).write_text(json.dumps(data,indent=2),encoding='utf-8')
        return report


def install_repository_tools(repository):
    source = Path(__file__).resolve().parent
    runtime_files = (
        'cloud_inventory.py', 'setup_flow.py', 'snapshots.py', 'aws_inventory.py',
        'terraform_json.py', 'client_csv.py', 'migration.py', 'workflow.py', 'requirements.txt',
    )
    for name in runtime_files:
        original = source / name
        if name == 'requirements.txt' and not original.is_file():
            original = source.parent / 'resources' / name
        shutil.copyfile(original, repository / 'scripts' / name)
    policy = source / 'aws_discovery_policy.json'
    if not policy.is_file():
        policy = source.parent / 'policies' / policy.name
    if not policy.is_file():
        policy = source.parent / 'resources' / 'aws_discovery_policy.txt'
    shutil.copyfile(policy, repository / 'policies' / 'aws_discovery_policy.json')
    (repository / '.gitignore').write_text(
        '.venv/\nsetup_logs/\noutput/\n__pycache__/\n', encoding='utf-8')
    (repository / 'README.md').write_text(
        '# Terraform infrastructure\n\n'
        'Run the inventory tool from the repository root.\n\n'
        '```text\npython scripts/cloud_inventory.py -h\n```\n\n'
        'Terraform roots are under environments/. AWS roots also include a region directory.\n'
        'The AWS discovery policy under policies/ is a reference for review.\n',
        encoding='utf-8')


ENVIRONMENTS = ('dev', 'uat', 'prod')


def generate_json(provider, rows, folder, account, tenant=None, home_region='us-east-1', profile=None,
                  environment='dev'):
    """Generate one isolated Terraform repository per inventory run."""
    if environment not in ENVIRONMENTS:
        raise ValueError('Environment must be dev, uat or prod.')
    if provider not in ('azure', 'aws'):
        raise ValueError('Provider must be azure or aws')
    repository = Path(folder)
    repository.mkdir(parents=True, exist_ok=False)
    for directory in ('environments/dev', 'environments/uat', 'environments/prod',
                      'modules/azure', 'modules/aws', 'modules/shared/tags', 'modules/shared/naming',
                      'cloud-infra/foundation', 'policies', 'scripts', 'infra-pipelines/templates'):
        (repository / directory).mkdir(parents=True)
    install_repository_tools(repository)
    root = repository / 'environments' / environment
    # Compiler creates each Terraform root. Keep the other environments empty.
    if provider == 'azure':
        root.rmdir()
        return [Compiler(provider, normalize_azure(rows), root, account, tenant,
                         repository=repository).compile()]
    groups = defaultdict(list)
    for row in rows:
        if not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*', row['region']):
            raise ValueError('Invalid AWS region path')
        groups[row['region']].append(row)
    reports = []
    for region, group in sorted(groups.items()):
        reports.append(Compiler(provider, group, root / region, account,
                                region=home_region if region == 'global' else region,
                                profile=profile, repository=repository,
                                module_scope=region if len(groups) > 1 else None).compile())
    (repository / 'generation_report.json').write_text(json.dumps(reports, indent=2), encoding='utf-8')
    return reports
